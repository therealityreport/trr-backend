--
-- PostgreSQL database dump
--

\restrict EVo4Yluyi5cwg2X06NKbof6NCWNOXM33R0lXurrFMb3MnLDCPq0CSUAXghhnyos

-- Dumped from database version 17.10 (Homebrew)
-- Dumped by pg_dump version 17.10 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: core; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA core;


--
-- Name: dbos; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA dbos;


--
-- Name: social; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA social;


--
-- Name: pg_stat_statements; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_stat_statements WITH SCHEMA public;


--
-- Name: EXTENSION pg_stat_statements; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_stat_statements IS 'track planning and execution statistics of all SQL statements executed';


--
-- Name: enqueue_workflow(text, text, json[], json, text, text, text, text, bigint, bigint, text, integer, text, text, text, bigint, text); Type: FUNCTION; Schema: dbos; Owner: -
--

CREATE FUNCTION dbos.enqueue_workflow(workflow_name text, queue_name text, positional_args json[] DEFAULT ARRAY[]::json[], named_args json DEFAULT '{}'::json, class_name text DEFAULT NULL::text, config_name text DEFAULT NULL::text, workflow_id text DEFAULT NULL::text, app_version text DEFAULT NULL::text, timeout_ms bigint DEFAULT NULL::bigint, deadline_epoch_ms bigint DEFAULT NULL::bigint, deduplication_id text DEFAULT NULL::text, priority integer DEFAULT NULL::integer, queue_partition_key text DEFAULT NULL::text, authenticated_user text DEFAULT NULL::text, authenticated_roles text DEFAULT NULL::text, delay_until_epoch_ms bigint DEFAULT NULL::bigint, application_name text DEFAULT NULL::text) RETURNS text
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'pg_temp'
    AS $$
DECLARE
    v_workflow_id TEXT;
    v_serialized_inputs TEXT;
    v_owner_xid TEXT;
    v_now BIGINT;
    v_recovery_attempts INT4 := 0;
    v_priority INT4;
    v_status TEXT;
BEGIN

    -- Validate required parameters
    IF workflow_name IS NULL OR workflow_name = '' THEN
        RAISE EXCEPTION 'Workflow name cannot be null or empty';
    END IF;
    IF queue_name IS NULL OR queue_name = '' THEN
        RAISE EXCEPTION 'Queue name cannot be null or empty';
    END IF;
    IF named_args IS NOT NULL AND jsonb_typeof(named_args::jsonb) != 'object' THEN
        RAISE EXCEPTION 'Named args must be a JSON object';
    END IF;
    IF workflow_id IS NOT NULL AND workflow_id = '' THEN
        RAISE EXCEPTION 'Workflow ID cannot be an empty string if provided.';
    END IF;
    IF delay_until_epoch_ms IS NOT NULL AND delay_until_epoch_ms < 0 THEN
        RAISE EXCEPTION 'delay_until_epoch_ms must be >= 0';
    END IF;

    v_workflow_id := COALESCE(workflow_id, gen_random_uuid()::TEXT);
    v_owner_xid := gen_random_uuid()::TEXT;
    v_priority := COALESCE(priority, 0);
    v_serialized_inputs := json_build_object(
        'positionalArgs', positional_args,
        'namedArgs', named_args
    )::TEXT;
    v_now := EXTRACT(epoch FROM now()) * 1000;
    v_status := CASE WHEN delay_until_epoch_ms IS NULL THEN 'ENQUEUED' ELSE 'DELAYED' END;

    INSERT INTO "dbos".workflow_status (
        workflow_uuid, status,
        name, class_name, config_name,
        queue_name, deduplication_id, priority, queue_partition_key,
        application_version,
        created_at, updated_at, recovery_attempts,
        workflow_timeout_ms, workflow_deadline_epoch_ms,
        parent_workflow_id, owner_xid, serialization,
        authenticated_user, authenticated_roles,
        delay_until_epoch_ms, application_name
    ) VALUES (
        v_workflow_id, v_status,
        workflow_name, class_name, config_name,
        queue_name, deduplication_id, v_priority, queue_partition_key,
        app_version,
        v_now, v_now, v_recovery_attempts,
        timeout_ms, deadline_epoch_ms,
        NULL, v_owner_xid, 'portable_json',
        authenticated_user, authenticated_roles,
        delay_until_epoch_ms, application_name
    )
    ON CONFLICT (workflow_uuid)
    DO UPDATE SET
        updated_at = EXCLUDED.updated_at;

    INSERT INTO "dbos".workflow_input (
        workflow_uuid, inputs, retention_timestamp
    ) VALUES (
        v_workflow_id, v_serialized_inputs, v_now
    )
    ON CONFLICT (workflow_uuid) DO NOTHING;

    RETURN v_workflow_id;

EXCEPTION
    WHEN unique_violation THEN
        RAISE EXCEPTION 'DBOS queue duplicated'
            USING DETAIL = format('Workflow %s with queue %s and deduplication ID %s already exists', v_workflow_id, queue_name, deduplication_id),
                ERRCODE = 'unique_violation';
END;
$$;


--
-- Name: notifications_function(); Type: FUNCTION; Schema: dbos; Owner: -
--

CREATE FUNCTION dbos.notifications_function() RETURNS trigger
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'pg_temp'
    AS $$
DECLARE
    payload text := NEW.destination_uuid || '::' || NEW.topic;
BEGIN
    PERFORM pg_notify('dbos_notifications_channel', payload);
    RETURN NEW;
END;
$$;


--
-- Name: send_message(text, json, text, text); Type: FUNCTION; Schema: dbos; Owner: -
--

CREATE FUNCTION dbos.send_message(destination_id text, message json, topic text DEFAULT NULL::text, message_id text DEFAULT NULL::text) RETURNS void
    LANGUAGE plpgsql
    SET search_path TO 'pg_catalog', 'pg_temp'
    AS $$
DECLARE
    v_topic TEXT := COALESCE(topic, '__null__topic__');
    v_message_id TEXT := COALESCE(message_id, gen_random_uuid()::TEXT);
BEGIN
    INSERT INTO "dbos".notifications (
        destination_uuid, topic, message, message_uuid, serialization
    ) VALUES (
        destination_id, v_topic, message, v_message_id, 'portable_json'
    )
    ON CONFLICT (message_uuid) DO NOTHING;
EXCEPTION
    WHEN foreign_key_violation THEN
        RAISE EXCEPTION 'DBOS non-existent workflow'
            USING DETAIL = format('Destination workflow %s does not exist', destination_id),
                ERRCODE = 'foreign_key_violation';
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: episodes; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.episodes (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    season_id uuid,
    episode_number integer,
    air_date date
);


--
-- Name: people; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.people (
    id uuid NOT NULL
);


--
-- Name: seasons; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.seasons (
    id uuid NOT NULL,
    show_id uuid,
    season_number integer,
    title text,
    premiere_date date,
    air_date date
);


--
-- Name: shows; Type: TABLE; Schema: core; Owner: -
--

CREATE TABLE core.shows (
    id uuid NOT NULL,
    name text,
    slug text
);


--
-- Name: application_versions; Type: TABLE; Schema: dbos; Owner: -
--

CREATE TABLE dbos.application_versions (
    version_id text NOT NULL,
    version_name text NOT NULL,
    version_timestamp bigint DEFAULT ((EXTRACT(epoch FROM now()) * 1000.0))::bigint NOT NULL,
    created_at bigint DEFAULT ((EXTRACT(epoch FROM now()) * 1000.0))::bigint NOT NULL,
    application_name text
);


--
-- Name: dbos_migrations; Type: TABLE; Schema: dbos; Owner: -
--

CREATE TABLE dbos.dbos_migrations (
    version bigint NOT NULL
);


--
-- Name: event_dispatch_kv; Type: TABLE; Schema: dbos; Owner: -
--

CREATE TABLE dbos.event_dispatch_kv (
    service_name text NOT NULL,
    workflow_fn_name text NOT NULL,
    key text NOT NULL,
    value text,
    update_seq numeric(38,0),
    update_time numeric(38,15)
);


--
-- Name: notifications; Type: TABLE; Schema: dbos; Owner: -
--

CREATE TABLE dbos.notifications (
    message_uuid text DEFAULT gen_random_uuid() NOT NULL,
    destination_uuid text NOT NULL,
    topic text,
    message text NOT NULL,
    created_at_epoch_ms bigint DEFAULT ((EXTRACT(epoch FROM now()) * 1000.0))::bigint NOT NULL,
    serialization text,
    consumed boolean DEFAULT false NOT NULL,
    consumed_by_function_id integer
);


--
-- Name: operation_outputs; Type: TABLE; Schema: dbos; Owner: -
--

CREATE TABLE dbos.operation_outputs (
    workflow_uuid text NOT NULL,
    function_id integer NOT NULL,
    function_name text DEFAULT ''::text NOT NULL,
    output text,
    error text,
    child_workflow_id text,
    started_at_epoch_ms bigint,
    completed_at_epoch_ms bigint,
    serialization text,
    application_name text,
    retention_timestamp bigint DEFAULT ((EXTRACT(epoch FROM now()) * 1000.0))::bigint NOT NULL
);


--
-- Name: queues; Type: TABLE; Schema: dbos; Owner: -
--

CREATE TABLE dbos.queues (
    queue_id text DEFAULT (gen_random_uuid())::text NOT NULL,
    name text NOT NULL,
    concurrency integer,
    worker_concurrency integer,
    rate_limit_max integer,
    rate_limit_period_sec double precision,
    priority_enabled boolean DEFAULT false NOT NULL,
    partition_queue boolean DEFAULT false NOT NULL,
    polling_interval_sec double precision DEFAULT 1.0 NOT NULL,
    created_at bigint DEFAULT ((EXTRACT(epoch FROM now()) * 1000.0))::bigint NOT NULL,
    updated_at bigint DEFAULT ((EXTRACT(epoch FROM now()) * 1000.0))::bigint NOT NULL,
    application_name text,
    partition_concurrency integer,
    partition_worker_concurrency integer,
    partition_rate_limit_max integer,
    partition_rate_limit_period_sec double precision
);


--
-- Name: streams; Type: TABLE; Schema: dbos; Owner: -
--

CREATE TABLE dbos.streams (
    workflow_uuid text NOT NULL,
    key text NOT NULL,
    value text NOT NULL,
    "offset" integer NOT NULL,
    function_id integer DEFAULT 0 NOT NULL,
    serialization text
);


--
-- Name: workflow_events; Type: TABLE; Schema: dbos; Owner: -
--

CREATE TABLE dbos.workflow_events (
    workflow_uuid text NOT NULL,
    key text NOT NULL,
    value text NOT NULL,
    serialization text
);


--
-- Name: workflow_events_history; Type: TABLE; Schema: dbos; Owner: -
--

CREATE TABLE dbos.workflow_events_history (
    workflow_uuid text NOT NULL,
    function_id integer NOT NULL,
    key text NOT NULL,
    value text NOT NULL,
    serialization text
);


--
-- Name: workflow_input; Type: TABLE; Schema: dbos; Owner: -
--

CREATE TABLE dbos.workflow_input (
    workflow_uuid text NOT NULL,
    inputs text,
    retention_timestamp bigint DEFAULT ((EXTRACT(epoch FROM now()) * 1000.0))::bigint NOT NULL
);


--
-- Name: workflow_output; Type: TABLE; Schema: dbos; Owner: -
--

CREATE TABLE dbos.workflow_output (
    workflow_uuid text NOT NULL,
    output text,
    error text,
    retention_timestamp bigint DEFAULT ((EXTRACT(epoch FROM now()) * 1000.0))::bigint NOT NULL
);


--
-- Name: workflow_schedules; Type: TABLE; Schema: dbos; Owner: -
--

CREATE TABLE dbos.workflow_schedules (
    schedule_id text NOT NULL,
    schedule_name text NOT NULL,
    workflow_name text NOT NULL,
    workflow_class_name text,
    schedule text NOT NULL,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    context text NOT NULL,
    last_fired_at text,
    automatic_backfill boolean DEFAULT false NOT NULL,
    cron_timezone text,
    queue_name text,
    application_name text
);


--
-- Name: workflow_status; Type: TABLE; Schema: dbos; Owner: -
--

CREATE TABLE dbos.workflow_status (
    workflow_uuid text NOT NULL,
    status text,
    name text,
    authenticated_user text,
    assumed_role text,
    authenticated_roles text,
    request text,
    output text,
    error text,
    executor_id text,
    created_at bigint DEFAULT ((EXTRACT(epoch FROM now()) * 1000.0))::bigint NOT NULL,
    updated_at bigint DEFAULT ((EXTRACT(epoch FROM now()) * 1000.0))::bigint NOT NULL,
    application_version text,
    application_id text,
    class_name character varying(255) DEFAULT NULL::character varying,
    config_name character varying(255) DEFAULT NULL::character varying,
    recovery_attempts bigint DEFAULT 0,
    queue_name text,
    workflow_timeout_ms bigint,
    workflow_deadline_epoch_ms bigint,
    inputs text,
    started_at_epoch_ms bigint,
    deduplication_id text,
    priority integer DEFAULT 0 NOT NULL,
    queue_partition_key text,
    forked_from text,
    owner_xid text,
    parent_workflow_id text,
    serialization text,
    delay_until_epoch_ms bigint,
    was_forked_from boolean DEFAULT false NOT NULL,
    rate_limited boolean DEFAULT false NOT NULL,
    completed_at bigint,
    attributes jsonb,
    schedule_name text,
    debounce_deadline_epoch_ms bigint,
    is_debounced boolean DEFAULT false NOT NULL,
    application_name text,
    creator_xid text
);


--
-- Name: account_auth_cooldown; Type: TABLE; Schema: social; Owner: -
--

CREATE TABLE social.account_auth_cooldown (
    platform text NOT NULL,
    account_handle text NOT NULL,
    cooldown_until timestamp with time zone,
    consecutive_auth_failures integer DEFAULT 0 NOT NULL,
    last_error_code text,
    blocker_kind text DEFAULT 'auth'::text NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT account_auth_cooldown_blocker_kind_check CHECK ((blocker_kind = ANY (ARRAY['auth'::text, 'checkpoint'::text]))),
    CONSTRAINT account_auth_cooldown_consecutive_auth_failures_check CHECK ((consecutive_auth_failures >= 0))
);


--
-- Name: TABLE account_auth_cooldown; Type: COMMENT; Schema: social; Owner: -
--

COMMENT ON TABLE social.account_auth_cooldown IS 'Cross-process (Modal-container-safe) account auth cooldown for the social posts/comments backfill reliability layer. Keyed on (platform, account_handle).';


--
-- Name: COLUMN account_auth_cooldown.cooldown_until; Type: COMMENT; Schema: social; Owner: -
--

COMMENT ON COLUMN social.account_auth_cooldown.cooldown_until IS 'When set and in the future, no authenticated request should be issued for this account; the job soft-stops and requeues with available_at = cooldown_until.';


--
-- Name: COLUMN account_auth_cooldown.consecutive_auth_failures; Type: COMMENT; Schema: social; Owner: -
--

COMMENT ON COLUMN social.account_auth_cooldown.consecutive_auth_failures IS 'Drives escalating exponential backoff (exponential_backoff_delay) for cooldown_until; reset to 0 on a clean page fetch.';


--
-- Name: COLUMN account_auth_cooldown.blocker_kind; Type: COMMENT; Schema: social; Owner: -
--

COMMENT ON COLUMN social.account_auth_cooldown.blocker_kind IS 'auth = transient 401/403 (rotate + bounded retry allowed); checkpoint = challenge/checkpoint/login_required (non-clearing, no auto-rotate-retry, needs operator action).';


--
-- Name: avatar_registry; Type: TABLE; Schema: social; Owner: -
--

CREATE TABLE social.avatar_registry (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    platform text,
    account_handle text,
    source_url text,
    content_hash text,
    hosted_url text,
    status text,
    failure_reason text,
    last_checked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


--
-- Name: instagram_comments; Type: TABLE; Schema: social; Owner: -
--

CREATE TABLE social.instagram_comments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    comment_id text NOT NULL,
    post_id uuid NOT NULL,
    parent_comment_id uuid,
    username text NOT NULL,
    user_id text,
    text text NOT NULL,
    likes integer DEFAULT 0 NOT NULL,
    is_reply boolean DEFAULT false NOT NULL,
    reply_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone,
    scraped_at timestamp with time zone DEFAULT now() NOT NULL,
    raw_data jsonb,
    season_id uuid,
    job_id uuid,
    source_account text,
    is_missing boolean DEFAULT false NOT NULL,
    missing_at timestamp with time zone,
    first_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_run_id uuid,
    media_urls jsonb DEFAULT '[]'::jsonb NOT NULL,
    hosted_media_urls jsonb DEFAULT '[]'::jsonb NOT NULL,
    media_mirror_status text,
    media_mirror_error text,
    media_mirror_attempt_count integer,
    media_mirror_last_attempt_at timestamp with time zone,
    media_mirror_last_job_id text,
    hosted_author_profile_pic_url text,
    deleted_at timestamp with time zone,
    author_profile_pic_url text,
    author_is_verified boolean,
    author_full_name text,
    author_profile_pic_url_hd text,
    parent_comment_external_id text,
    root_comment_id uuid,
    reply_depth integer,
    source_snapshot_type text,
    comment_url text,
    author_fbid_v2 text,
    author_is_mentionable boolean,
    author_is_private boolean,
    author_latest_reel_media bigint,
    author_profile_pic_id text,
    is_covered boolean DEFAULT false NOT NULL,
    is_ranked boolean DEFAULT false NOT NULL,
    comment_index integer,
    phase text,
    did_report_as_spam boolean DEFAULT false NOT NULL,
    status text DEFAULT 'Active'::text NOT NULL,
    is_edited boolean DEFAULT false NOT NULL,
    is_pinned boolean DEFAULT false NOT NULL,
    meta_ai_comment_type text DEFAULT 'NONE'::text NOT NULL,
    child_comment_count integer DEFAULT 0 NOT NULL,
    liked_by_media_coauthors boolean DEFAULT false NOT NULL,
    cursor_min_id text,
    cursor_param text,
    cursor_payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    comment_filter_param text,
    CONSTRAINT instagram_comments_author_latest_reel_media_check CHECK (((author_latest_reel_media IS NULL) OR (author_latest_reel_media >= 0))),
    CONSTRAINT instagram_comments_reply_depth_check CHECK (((reply_depth IS NULL) OR (reply_depth >= 0)))
);


--
-- Name: COLUMN instagram_comments.reply_count; Type: COMMENT; Schema: social; Owner: -
--

COMMENT ON COLUMN social.instagram_comments.reply_count IS 'Legacy scraper-observed reply count from comment payloads; use child_comment_count for Instagram authoritative child totals when present.';


--
-- Name: COLUMN instagram_comments.is_covered; Type: COMMENT; Schema: social; Owner: -
--

COMMENT ON COLUMN social.instagram_comments.is_covered IS 'True when Instagram reports the comment as covered or masked by an upstream filter.';


--
-- Name: COLUMN instagram_comments.is_ranked; Type: COMMENT; Schema: social; Owner: -
--

COMMENT ON COLUMN social.instagram_comments.is_ranked IS 'True when the row was observed in Instagram ranked/top-load ordering; preserve ranked ordinals when later pages repeat the comment.';


--
-- Name: COLUMN instagram_comments.comment_index; Type: COMMENT; Schema: social; Owner: -
--

COMMENT ON COLUMN social.instagram_comments.comment_index IS 'Upstream comment ordinal within the producing phase, especially ranked ordering; null when unavailable.';


--
-- Name: COLUMN instagram_comments.phase; Type: COMMENT; Schema: social; Owner: -
--

COMMENT ON COLUMN social.instagram_comments.phase IS 'Instagram comment capture phase that produced this row: ranked, headload, fb_crosspost, or child.';


--
-- Name: COLUMN instagram_comments.did_report_as_spam; Type: COMMENT; Schema: social; Owner: -
--

COMMENT ON COLUMN social.instagram_comments.did_report_as_spam IS 'Whether Instagram reports that the viewer/account marked this comment as spam.';


--
-- Name: COLUMN instagram_comments.status; Type: COMMENT; Schema: social; Owner: -
--

COMMENT ON COLUMN social.instagram_comments.status IS 'Instagram-reported comment status, defaulting to Active when the API omits status details.';


--
-- Name: COLUMN instagram_comments.is_edited; Type: COMMENT; Schema: social; Owner: -
--

COMMENT ON COLUMN social.instagram_comments.is_edited IS 'Whether Instagram reports the comment text was edited after initial creation.';


--
-- Name: COLUMN instagram_comments.is_pinned; Type: COMMENT; Schema: social; Owner: -
--

COMMENT ON COLUMN social.instagram_comments.is_pinned IS 'Whether Instagram reports the comment is pinned on the media.';


--
-- Name: COLUMN instagram_comments.meta_ai_comment_type; Type: COMMENT; Schema: social; Owner: -
--

COMMENT ON COLUMN social.instagram_comments.meta_ai_comment_type IS 'Instagram Meta AI comment type marker, defaulting to NONE when absent.';


--
-- Name: COLUMN instagram_comments.child_comment_count; Type: COMMENT; Schema: social; Owner: -
--

COMMENT ON COLUMN social.instagram_comments.child_comment_count IS 'Authoritative child-comment total reported by Instagram for the comment, not the number of replies already persisted locally.';


--
-- Name: COLUMN instagram_comments.liked_by_media_coauthors; Type: COMMENT; Schema: social; Owner: -
--

COMMENT ON COLUMN social.instagram_comments.liked_by_media_coauthors IS 'Whether Instagram reports the comment was liked by media coauthors.';


--
-- Name: COLUMN instagram_comments.cursor_min_id; Type: COMMENT; Schema: social; Owner: -
--

COMMENT ON COLUMN social.instagram_comments.cursor_min_id IS 'Cursor value used for min_id-compatible pagination when the comment page was captured.';


--
-- Name: COLUMN instagram_comments.cursor_param; Type: COMMENT; Schema: social; Owner: -
--

COMMENT ON COLUMN social.instagram_comments.cursor_param IS 'Name of the Instagram cursor parameter that produced the row: min_id, max_id, cached_comments_cursor, bifilter_token, or tao_cursor.';


--
-- Name: COLUMN instagram_comments.cursor_payload; Type: COMMENT; Schema: social; Owner: -
--

COMMENT ON COLUMN social.instagram_comments.cursor_payload IS 'Sanitized cursor envelope returned by Instagram for the page that yielded this comment; excludes cookies, headers, and secrets.';


--
-- Name: COLUMN instagram_comments.comment_filter_param; Type: COMMENT; Schema: social; Owner: -
--

COMMENT ON COLUMN social.instagram_comments.comment_filter_param IS 'Instagram comment filter mode requested for the page, such as default, hidden, or covered-comment retrieval.';


--
-- Name: instagram_posts; Type: TABLE; Schema: social; Owner: -
--

CREATE TABLE social.instagram_posts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    shortcode text NOT NULL,
    media_id text,
    username text NOT NULL,
    user_id text,
    caption text,
    media_type text,
    media_urls jsonb DEFAULT '[]'::jsonb NOT NULL,
    likes integer DEFAULT 0 NOT NULL,
    comments_count integer DEFAULT 0 NOT NULL,
    views integer,
    posted_at timestamp with time zone,
    scraped_at timestamp with time zone DEFAULT now() NOT NULL,
    raw_data jsonb,
    show_id uuid,
    person_id uuid,
    season_id uuid,
    job_id uuid,
    source_account text,
    thumbnail_url text,
    post_format text,
    profile_tags jsonb DEFAULT '[]'::jsonb NOT NULL,
    collaborators jsonb DEFAULT '[]'::jsonb NOT NULL,
    hashtags jsonb DEFAULT '[]'::jsonb NOT NULL,
    mentions jsonb DEFAULT '[]'::jsonb NOT NULL,
    duration_seconds integer,
    metadata_source text,
    metadata_scraped_at timestamp with time zone,
    metadata_error text,
    hosted_thumbnail_url text,
    hosted_media_urls jsonb DEFAULT '[]'::jsonb NOT NULL,
    media_mirror_status text,
    media_mirror_error text,
    media_mirror_attempt_count integer,
    media_mirror_last_attempt_at timestamp with time zone,
    media_mirror_last_job_id text,
    asset_manifest jsonb DEFAULT '{}'::jsonb NOT NULL,
    search_text text DEFAULT ''::text NOT NULL,
    search_hashtags text[] DEFAULT ARRAY[]::text[] NOT NULL,
    search_handles text[] DEFAULT ARRAY[]::text[] NOT NULL,
    search_handle_identities text[] DEFAULT ARRAY[]::text[] NOT NULL,
    metadata_last_attempted_at timestamp with time zone,
    metadata_last_failed_at timestamp with time zone,
    metadata_consecutive_failures integer DEFAULT 0 NOT NULL,
    tagged_users_detail jsonb DEFAULT '[]'::jsonb NOT NULL,
    collaborators_detail jsonb DEFAULT '[]'::jsonb NOT NULL,
    owner_profile_pic_url text,
    owner_full_name text,
    owner_is_verified boolean,
    product_type text,
    video_play_count integer,
    alt_text text,
    width integer,
    height integer,
    is_comments_disabled boolean,
    music_info jsonb,
    video_duration numeric,
    child_posts_data jsonb DEFAULT '[]'::jsonb NOT NULL,
    hosted_owner_profile_pic_url text,
    hosted_tagged_profile_pics jsonb DEFAULT '{}'::jsonb NOT NULL,
    profile_pic_mirror_status text,
    profile_pic_mirror_error text,
    source_input_url text,
    source_post_id text,
    permalink text,
    caption_id text,
    caption_is_edited boolean,
    caption_has_translation boolean,
    owner_user_id text,
    owner_username text,
    owner_profile_pic_url_hd text,
    location_id text,
    location_name text,
    location_raw jsonb DEFAULT '{}'::jsonb NOT NULL,
    original_width integer,
    original_height integer,
    like_and_view_counts_disabled boolean,
    comments_disabled boolean,
    commenting_disabled_for_viewer boolean,
    media_repost_count integer,
    is_paid_partnership boolean,
    is_advertisement boolean,
    can_viewer_reshare boolean,
    has_audio boolean,
    audio_url text,
    fb_comment_count integer,
    fb_like_count integer,
    is_shared_to_fb boolean,
    crosspost_metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    social_context jsonb DEFAULT '{}'::jsonb NOT NULL,
    facebook_post_id text,
    facebook_post_url text,
    facebook_crosspost_observed_at timestamp with time zone,
    facebook_crosspost_source text,
    CONSTRAINT instagram_posts_media_repost_count_check CHECK (((media_repost_count IS NULL) OR (media_repost_count >= 0))),
    CONSTRAINT instagram_posts_original_height_check CHECK (((original_height IS NULL) OR (original_height >= 0))),
    CONSTRAINT instagram_posts_original_width_check CHECK (((original_width IS NULL) OR (original_width >= 0)))
);


--
-- Name: comment_capture_health; Type: VIEW; Schema: social; Owner: -
--

CREATE VIEW social.comment_capture_health WITH (security_invoker='on') AS
 WITH comment_rollup AS (
         SELECT instagram_comments.post_id,
            count(*) FILTER (WHERE (instagram_comments.phase IS DISTINCT FROM 'fb_crosspost'::text)) AS saved_comment_count,
            count(*) FILTER (WHERE ((instagram_comments.phase IS DISTINCT FROM 'fb_crosspost'::text) AND (instagram_comments.parent_comment_id IS NULL))) AS saved_parent_comments,
            count(*) FILTER (WHERE ((instagram_comments.phase IS DISTINCT FROM 'fb_crosspost'::text) AND ((instagram_comments.parent_comment_id IS NOT NULL) OR instagram_comments.is_reply))) AS saved_child_replies,
            count(*) FILTER (WHERE (instagram_comments.phase = 'ranked'::text)) AS phase_ranked_count,
            count(*) FILTER (WHERE (instagram_comments.phase = 'headload'::text)) AS phase_headload_count,
            count(*) FILTER (WHERE (instagram_comments.phase = 'fb_crosspost'::text)) AS phase_fb_crosspost_count,
            count(*) FILTER (WHERE (instagram_comments.phase = 'child'::text)) AS phase_child_count,
            count(*) FILTER (WHERE (instagram_comments.phase IS NULL)) AS phase_unknown_count,
            count(*) FILTER (WHERE instagram_comments.is_covered) AS covered_comment_count,
            count(*) FILTER (WHERE instagram_comments.did_report_as_spam) AS spam_report_count,
            count(*) FILTER (WHERE (instagram_comments.status <> 'Active'::text)) AS inactive_status_count,
            COALESCE(sum(instagram_comments.child_comment_count), (0)::bigint) AS reported_child_comment_total,
            max(instagram_comments.scraped_at) AS last_comment_scraped_at
           FROM social.instagram_comments
          GROUP BY instagram_comments.post_id
        ), status_rollup AS (
         SELECT counts.post_id,
            jsonb_object_agg(counts.status, counts.status_count ORDER BY counts.status) AS status_counts
           FROM ( SELECT instagram_comments.post_id,
                    instagram_comments.status,
                    (count(*))::integer AS status_count
                   FROM social.instagram_comments
                  GROUP BY instagram_comments.post_id, instagram_comments.status) counts
          GROUP BY counts.post_id
        )
 SELECT p.id AS post_id,
    p.shortcode,
    p.media_id,
    p.username,
    p.source_account,
    p.season_id,
    p.job_id,
    p.comments_count AS instagram_reported_comments,
    COALESCE(p.fb_comment_count, 0) AS facebook_reported_comments,
    COALESCE(c.saved_comment_count, (0)::bigint) AS saved_comment_count,
    COALESCE(c.saved_parent_comments, (0)::bigint) AS saved_parent_comments,
    COALESCE(c.saved_child_replies, (0)::bigint) AS saved_child_replies,
    COALESCE(c.phase_ranked_count, (0)::bigint) AS phase_ranked_count,
    COALESCE(c.phase_headload_count, (0)::bigint) AS phase_headload_count,
    COALESCE(c.phase_fb_crosspost_count, (0)::bigint) AS phase_fb_crosspost_count,
    COALESCE(c.phase_child_count, (0)::bigint) AS phase_child_count,
    COALESCE(c.phase_unknown_count, (0)::bigint) AS phase_unknown_count,
    COALESCE(c.covered_comment_count, (0)::bigint) AS covered_comment_count,
    COALESCE(c.spam_report_count, (0)::bigint) AS spam_report_count,
    COALESCE(c.inactive_status_count, (0)::bigint) AS inactive_status_count,
    COALESCE(s.status_counts, '{}'::jsonb) AS status_counts,
    COALESCE(c.reported_child_comment_total, (0)::bigint) AS reported_child_comment_total,
    GREATEST(((COALESCE(p.comments_count, 0))::bigint - COALESCE(c.saved_parent_comments, (0)::bigint)), (0)::bigint) AS parent_capture_gap,
        CASE
            WHEN (COALESCE(p.comments_count, 0) > 0) THEN round((((COALESCE(c.saved_parent_comments, (0)::bigint))::numeric / (p.comments_count)::numeric) * (100)::numeric), 2)
            ELSE NULL::numeric
        END AS parent_capture_rate_pct,
    c.last_comment_scraped_at,
    p.scraped_at AS post_scraped_at
   FROM ((social.instagram_posts p
     LEFT JOIN comment_rollup c ON ((c.post_id = p.id)))
     LEFT JOIN status_rollup s ON ((s.post_id = p.id)));


--
-- Name: VIEW comment_capture_health; Type: COMMENT; Schema: social; Owner: -
--

COMMENT ON VIEW social.comment_capture_health IS 'Per-Instagram-post comment capture health, including phase counts, covered/status counts, and parent capture gap evidence.';


--
-- Name: ig_comment_rate_pace; Type: TABLE; Schema: social; Owner: -
--

CREATE TABLE social.ig_comment_rate_pace (
    rate_key text NOT NULL,
    last_start timestamp with time zone DEFAULT now() NOT NULL,
    cooldown_until timestamp with time zone
);


--
-- Name: TABLE ig_comment_rate_pace; Type: COMMENT; Schema: social; Owner: -
--

COMMENT ON TABLE social.ig_comment_rate_pace IS 'IG comments lane cross-container request pacing: one row per global_rate_limit_key. last_start = most recently claimed request slot (DB clock). Updated via atomic upsert reservation in fetcher._try_advisory_lock_pace; replaces advisory-lock-with-in-lock-sleep.';


--
-- Name: instagram_account_catalog_post_collaborators; Type: TABLE; Schema: social; Owner: -
--

CREATE TABLE social.instagram_account_catalog_post_collaborators (
    catalog_post_id uuid NOT NULL,
    source_id text NOT NULL,
    source_account text NOT NULL,
    collaborator_handle text NOT NULL,
    collaborator_source text NOT NULL,
    posted_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT instagram_account_catalog_post_collab_collaborator_source_check CHECK ((collaborator_source = ANY (ARRAY['collaborators'::text, 'collaborators_detail'::text])))
);


--
-- Name: instagram_account_catalog_post_payloads; Type: TABLE; Schema: social; Owner: -
--

CREATE TABLE social.instagram_account_catalog_post_payloads (
    catalog_post_id uuid NOT NULL,
    raw_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    child_posts_data jsonb DEFAULT '[]'::jsonb NOT NULL,
    payload_updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: instagram_account_catalog_posts; Type: TABLE; Schema: social; Owner: -
--

CREATE TABLE social.instagram_account_catalog_posts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    source_id text NOT NULL,
    source_account text NOT NULL,
    posted_at timestamp with time zone,
    permalink text,
    title text,
    caption text,
    description text,
    text text,
    media_type text,
    media_urls jsonb DEFAULT '[]'::jsonb NOT NULL,
    thumbnail_url text,
    hashtags jsonb DEFAULT '[]'::jsonb NOT NULL,
    mentions jsonb DEFAULT '[]'::jsonb NOT NULL,
    collaborators jsonb DEFAULT '[]'::jsonb NOT NULL,
    profile_tags jsonb DEFAULT '[]'::jsonb NOT NULL,
    likes bigint DEFAULT 0 NOT NULL,
    comments_count bigint DEFAULT 0 NOT NULL,
    views bigint DEFAULT 0 NOT NULL,
    shares bigint DEFAULT 0 NOT NULL,
    retweets bigint DEFAULT 0 NOT NULL,
    replies_count bigint DEFAULT 0 NOT NULL,
    quotes bigint DEFAULT 0 NOT NULL,
    raw_data jsonb DEFAULT '{}'::jsonb NOT NULL,
    assignment_status text DEFAULT 'unassigned'::text NOT NULL,
    assigned_show_id uuid,
    assigned_season_id uuid,
    assignment_source text,
    candidate_matches jsonb DEFAULT '[]'::jsonb NOT NULL,
    last_backfill_run_id uuid,
    first_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    music_info jsonb DEFAULT '{}'::jsonb NOT NULL,
    audio_url text,
    paid_partnership boolean DEFAULT false NOT NULL,
    child_posts_data jsonb DEFAULT '[]'::jsonb NOT NULL,
    owner_username text,
    video_play_count bigint DEFAULT 0 NOT NULL,
    video_duration numeric,
    CONSTRAINT instagram_account_catalog_posts_assignment_status_check CHECK ((assignment_status = ANY (ARRAY['assigned'::text, 'unassigned'::text, 'ambiguous'::text, 'needs_review'::text])))
);


--
-- Name: instagram_detail_request_lanes; Type: TABLE; Schema: social; Owner: -
--

CREATE TABLE social.instagram_detail_request_lanes (
    identity_key text NOT NULL,
    request_times timestamp with time zone[] DEFAULT '{}'::timestamp with time zone[] NOT NULL,
    cooldown_until timestamp with time zone,
    blocked boolean DEFAULT false NOT NULL,
    blocked_fingerprint text,
    last_error_code text,
    consecutive_failures integer DEFAULT 0 NOT NULL,
    failure_generation bigint DEFAULT 0 NOT NULL,
    probe_token text,
    probe_expires_at timestamp with time zone
);


--
-- Name: instagram_detail_run_targets; Type: TABLE; Schema: social; Owner: -
--

CREATE TABLE social.instagram_detail_run_targets (
    run_id uuid NOT NULL,
    source_id text NOT NULL,
    target_key text NOT NULL,
    account_handle text NOT NULL,
    required_mask jsonb NOT NULL,
    policy_version integer NOT NULL,
    state text DEFAULT 'pending'::text NOT NULL,
    attempt_count integer DEFAULT 0 NOT NULL,
    request_count integer DEFAULT 0 NOT NULL,
    next_attempt_at timestamp with time zone,
    lease_owner text,
    lease_job_id uuid,
    lease_generation bigint DEFAULT 0 NOT NULL,
    lease_expires_at timestamp with time zone,
    fetched_at timestamp with time zone,
    committed_at timestamp with time zone,
    error_code text,
    error_summary text,
    phase_elapsed_ms jsonb DEFAULT '{}'::jsonb NOT NULL,
    CONSTRAINT instagram_detail_run_targets_attempt_count_check CHECK ((attempt_count >= 0)),
    CONSTRAINT instagram_detail_run_targets_check CHECK (((state <> 'committed'::text) OR ((fetched_at IS NOT NULL) AND (committed_at IS NOT NULL)))),
    CONSTRAINT instagram_detail_run_targets_request_count_check CHECK ((request_count >= 0)),
    CONSTRAINT instagram_detail_run_targets_state_check CHECK ((state = ANY (ARRAY['pending'::text, 'leased'::text, 'committed'::text, 'cached_satisfied'::text, 'source_unavailable'::text, 'retry_wait'::text, 'failed'::text])))
);


--
-- Name: instagram_ingestion_commands; Type: TABLE; Schema: social; Owner: -
--

CREATE TABLE social.instagram_ingestion_commands (
    account text NOT NULL,
    idempotency_key text NOT NULL,
    command_hash text NOT NULL,
    run_id uuid NOT NULL,
    result jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL
);


--
-- Name: instagram_ingestion_comment_pages; Type: TABLE; Schema: social; Owner: -
--

CREATE TABLE social.instagram_ingestion_comment_pages (
    page_id uuid NOT NULL,
    run_id uuid NOT NULL,
    stage text DEFAULT 'comments'::text NOT NULL,
    target_key text NOT NULL,
    owner_generation bigint NOT NULL,
    evidence_id uuid NOT NULL,
    observed_at timestamp with time zone NOT NULL,
    content_hash text NOT NULL,
    parent_comment_id text,
    next_cursor text,
    exhausted boolean NOT NULL,
    canonical_identity jsonb NOT NULL,
    checkpoint jsonb NOT NULL,
    committed_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT instagram_ingestion_comment_pages_stage_check CHECK ((stage = 'comments'::text))
);


--
-- Name: instagram_ingestion_decisions; Type: TABLE; Schema: social; Owner: -
--

CREATE TABLE social.instagram_ingestion_decisions (
    execution_id text NOT NULL,
    ordinal integer NOT NULL,
    decision jsonb NOT NULL,
    CONSTRAINT instagram_ingestion_decisions_ordinal_check CHECK (((ordinal >= 0) AND (ordinal < 50)))
);


--
-- Name: instagram_ingestion_discovery_pages; Type: TABLE; Schema: social; Owner: -
--

CREATE TABLE social.instagram_ingestion_discovery_pages (
    run_id uuid NOT NULL,
    stage text NOT NULL,
    page_id text NOT NULL,
    request_hash text NOT NULL,
    committed_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL
);


--
-- Name: instagram_ingestion_dispatches; Type: TABLE; Schema: social; Owner: -
--

CREATE TABLE social.instagram_ingestion_dispatches (
    owner_token uuid NOT NULL,
    run_id uuid NOT NULL,
    generation bigint NOT NULL,
    stage text NOT NULL,
    target_key text NOT NULL,
    state text DEFAULT 'reserved'::text NOT NULL,
    remote_identity text,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    updated_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT instagram_ingestion_dispatches_state_check CHECK ((state = ANY (ARRAY['reserved'::text, 'sending'::text, 'accepted'::text, 'expired'::text])))
);


--
-- Name: instagram_ingestion_evidence; Type: TABLE; Schema: social; Owner: -
--

CREATE TABLE social.instagram_ingestion_evidence (
    evidence_id uuid NOT NULL,
    run_id uuid NOT NULL,
    stage text NOT NULL,
    target_key text NOT NULL,
    source_identity text NOT NULL,
    captured_at timestamp with time zone NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    content_hash text NOT NULL,
    parser_version text NOT NULL,
    schema_version integer NOT NULL,
    payload text,
    CONSTRAINT instagram_ingestion_evidence_check CHECK ((expires_at = (captured_at + '720:00:00'::interval))),
    CONSTRAINT instagram_ingestion_evidence_payload_check CHECK (((payload IS NULL) OR ((octet_length(payload) <= 4194304) AND (jsonb_typeof((payload)::jsonb) = 'object'::text))))
);


--
-- Name: instagram_ingestion_manifests; Type: TABLE; Schema: social; Owner: -
--

CREATE TABLE social.instagram_ingestion_manifests (
    run_id uuid NOT NULL,
    stage text NOT NULL,
    discovery_complete boolean DEFAULT false NOT NULL,
    cursor_state jsonb DEFAULT '{}'::jsonb NOT NULL,
    sealed_at timestamp with time zone,
    CONSTRAINT instagram_ingestion_manifests_check CHECK ((discovery_complete = (sealed_at IS NOT NULL))),
    CONSTRAINT instagram_ingestion_manifests_stage_check CHECK ((stage = ANY (ARRAY['listing'::text, 'post_details'::text, 'comments'::text, 'media'::text])))
);


--
-- Name: instagram_ingestion_outbox; Type: TABLE; Schema: social; Owner: -
--

CREATE TABLE social.instagram_ingestion_outbox (
    execution_id text NOT NULL,
    run_id uuid NOT NULL,
    generation bigint NOT NULL,
    available_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    acknowledged_at timestamp with time zone,
    attempts integer DEFAULT 0 NOT NULL,
    CONSTRAINT instagram_ingestion_outbox_attempts_check CHECK ((attempts >= 0))
);


--
-- Name: instagram_ingestion_partitions; Type: TABLE; Schema: social; Owner: -
--

CREATE TABLE social.instagram_ingestion_partitions (
    execution_id text NOT NULL,
    run_id uuid NOT NULL,
    generation bigint NOT NULL,
    partition_number bigint NOT NULL,
    engine text NOT NULL,
    workflow_version text NOT NULL,
    available_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    acknowledged_at timestamp with time zone,
    completed_at timestamp with time zone,
    next_execution_id text,
    CONSTRAINT instagram_ingestion_partitions_engine_check CHECK ((engine = 'dbos'::text)),
    CONSTRAINT instagram_ingestion_partitions_partition_number_check CHECK ((partition_number >= 0))
);


--
-- Name: instagram_ingestion_receipts; Type: TABLE; Schema: social; Owner: -
--

CREATE TABLE social.instagram_ingestion_receipts (
    receipt_id uuid NOT NULL,
    run_id uuid NOT NULL,
    stage text NOT NULL,
    target_key text NOT NULL,
    owner_token uuid NOT NULL,
    owner_generation bigint NOT NULL,
    evidence_id uuid,
    observed_at timestamp with time zone NOT NULL,
    committed_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    outcome text NOT NULL,
    canonical_identity jsonb NOT NULL,
    CONSTRAINT instagram_ingestion_receipts_outcome_check CHECK ((outcome = ANY (ARRAY['committed'::text, 'cached_satisfied'::text, 'source_unavailable'::text])))
);


--
-- Name: instagram_ingestion_runs; Type: TABLE; Schema: social; Owner: -
--

CREATE TABLE social.instagram_ingestion_runs (
    run_id uuid NOT NULL,
    account text NOT NULL,
    intent jsonb NOT NULL,
    intent_hash text NOT NULL,
    engine text NOT NULL,
    workflow_version text NOT NULL,
    state text DEFAULT 'queued'::text NOT NULL,
    generation bigint DEFAULT 1 NOT NULL,
    execution_selection jsonb,
    last_committed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    updated_at timestamp with time zone DEFAULT clock_timestamp() NOT NULL,
    CONSTRAINT instagram_ingestion_runs_engine_check CHECK ((engine = ANY (ARRAY['dbos'::text, 'temporal'::text]))),
    CONSTRAINT instagram_ingestion_runs_state_check CHECK ((state = ANY (ARRAY['queued'::text, 'running'::text, 'blocked'::text, 'cancelled'::text, 'completed'::text, 'failed'::text])))
);


--
-- Name: instagram_ingestion_targets; Type: TABLE; Schema: social; Owner: -
--

CREATE TABLE social.instagram_ingestion_targets (
    run_id uuid NOT NULL,
    stage text NOT NULL,
    target_key text NOT NULL,
    outcome text DEFAULT 'unresolved'::text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    requests integer DEFAULT 0 NOT NULL,
    max_attempts integer NOT NULL,
    next_attempt_at timestamp with time zone,
    blocked_reason text,
    owner_token uuid,
    owner_generation bigint DEFAULT 0 NOT NULL,
    owner_expires_at timestamp with time zone,
    owner_started_at timestamp with time zone,
    checkpoint jsonb DEFAULT '{}'::jsonb NOT NULL,
    observed_at timestamp with time zone,
    committed_at timestamp with time zone,
    CONSTRAINT instagram_ingestion_targets_attempts_check CHECK ((attempts >= 0)),
    CONSTRAINT instagram_ingestion_targets_check CHECK (((stage <> 'post_details'::text) OR (max_attempts = 3))),
    CONSTRAINT instagram_ingestion_targets_check1 CHECK (((outcome <> 'committed'::text) OR ((observed_at IS NOT NULL) AND (committed_at IS NOT NULL)))),
    CONSTRAINT instagram_ingestion_targets_max_attempts_check CHECK ((max_attempts > 0)),
    CONSTRAINT instagram_ingestion_targets_outcome_check CHECK ((outcome = ANY (ARRAY['unresolved'::text, 'committed'::text, 'cached_satisfied'::text, 'source_unavailable'::text]))),
    CONSTRAINT instagram_ingestion_targets_requests_check CHECK ((requests >= 0))
);


--
-- Name: instagram_post_comments_audit; Type: TABLE; Schema: social; Owner: -
--

CREATE TABLE social.instagram_post_comments_audit (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    scrape_run_id uuid,
    scrape_job_id uuid,
    post_id uuid NOT NULL,
    shortcode text,
    source_account text,
    reported_comment_count integer DEFAULT 0 NOT NULL,
    reported_fb_comment_count integer DEFAULT 0 NOT NULL,
    fetched_comment_count integer DEFAULT 0 NOT NULL,
    fetched_parent_comment_count integer DEFAULT 0 NOT NULL,
    fetched_child_comment_count integer DEFAULT 0 NOT NULL,
    phase_ranked_count integer DEFAULT 0 NOT NULL,
    phase_headload_count integer DEFAULT 0 NOT NULL,
    phase_fb_crosspost_count integer DEFAULT 0 NOT NULL,
    phase_child_count integer DEFAULT 0 NOT NULL,
    phase_counts jsonb DEFAULT '{}'::jsonb NOT NULL,
    covered_comment_count integer DEFAULT 0 NOT NULL,
    spam_report_count integer DEFAULT 0 NOT NULL,
    inactive_status_count integer DEFAULT 0 NOT NULL,
    status_counts jsonb DEFAULT '{}'::jsonb NOT NULL,
    cursor_stop_reason text,
    cursor_min_id text,
    cursor_param text,
    cursor_payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    comment_filter_param text,
    reported_parent_gap_count integer DEFAULT 0 NOT NULL,
    reported_child_gap_count integer DEFAULT 0 NOT NULL,
    reported_total_gap_count integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT instagram_post_comments_audi_fetched_parent_comment_count_check CHECK ((fetched_parent_comment_count >= 0)),
    CONSTRAINT instagram_post_comments_audit_covered_comment_count_check CHECK ((covered_comment_count >= 0)),
    CONSTRAINT instagram_post_comments_audit_cursor_param_check CHECK (((cursor_param IS NULL) OR (cursor_param = ANY (ARRAY['min_id'::text, 'max_id'::text, 'cached_comments_cursor'::text, 'bifilter_token'::text, 'tao_cursor'::text])))),
    CONSTRAINT instagram_post_comments_audit_fetched_child_comment_count_check CHECK ((fetched_child_comment_count >= 0)),
    CONSTRAINT instagram_post_comments_audit_fetched_comment_count_check CHECK ((fetched_comment_count >= 0)),
    CONSTRAINT instagram_post_comments_audit_inactive_status_count_check CHECK ((inactive_status_count >= 0)),
    CONSTRAINT instagram_post_comments_audit_phase_child_count_check CHECK ((phase_child_count >= 0)),
    CONSTRAINT instagram_post_comments_audit_phase_fb_crosspost_count_check CHECK ((phase_fb_crosspost_count >= 0)),
    CONSTRAINT instagram_post_comments_audit_phase_headload_count_check CHECK ((phase_headload_count >= 0)),
    CONSTRAINT instagram_post_comments_audit_phase_ranked_count_check CHECK ((phase_ranked_count >= 0)),
    CONSTRAINT instagram_post_comments_audit_reported_child_gap_count_check CHECK ((reported_child_gap_count >= 0)),
    CONSTRAINT instagram_post_comments_audit_reported_comment_count_check CHECK ((reported_comment_count >= 0)),
    CONSTRAINT instagram_post_comments_audit_reported_fb_comment_count_check CHECK ((reported_fb_comment_count >= 0)),
    CONSTRAINT instagram_post_comments_audit_reported_parent_gap_count_check CHECK ((reported_parent_gap_count >= 0)),
    CONSTRAINT instagram_post_comments_audit_reported_total_gap_count_check CHECK ((reported_total_gap_count >= 0)),
    CONSTRAINT instagram_post_comments_audit_spam_report_count_check CHECK ((spam_report_count >= 0))
);


--
-- Name: TABLE instagram_post_comments_audit; Type: COMMENT; Schema: social; Owner: -
--

COMMENT ON TABLE social.instagram_post_comments_audit IS 'Per-run Instagram comment capture audit snapshots for post totals, phase totals, cursor stop reasons, status counts, and gap evidence.';


--
-- Name: COLUMN instagram_post_comments_audit.scrape_run_id; Type: COMMENT; Schema: social; Owner: -
--

COMMENT ON COLUMN social.instagram_post_comments_audit.scrape_run_id IS 'Optional scrape run that produced this comment audit snapshot.';


--
-- Name: COLUMN instagram_post_comments_audit.scrape_job_id; Type: COMMENT; Schema: social; Owner: -
--

COMMENT ON COLUMN social.instagram_post_comments_audit.scrape_job_id IS 'Optional comments scrape job that produced this audit snapshot.';


--
-- Name: COLUMN instagram_post_comments_audit.phase_counts; Type: COMMENT; Schema: social; Owner: -
--

COMMENT ON COLUMN social.instagram_post_comments_audit.phase_counts IS 'Phase totals serialized from the worker when scalar phase columns are not enough for diagnostics.';


--
-- Name: COLUMN instagram_post_comments_audit.status_counts; Type: COMMENT; Schema: social; Owner: -
--

COMMENT ON COLUMN social.instagram_post_comments_audit.status_counts IS 'Comment status totals observed during the audit snapshot.';


--
-- Name: COLUMN instagram_post_comments_audit.cursor_stop_reason; Type: COMMENT; Schema: social; Owner: -
--

COMMENT ON COLUMN social.instagram_post_comments_audit.cursor_stop_reason IS 'Worker stop reason for the cursor loop, such as exhausted, budget_exhausted, checkpoint_required, or error.';


--
-- Name: COLUMN instagram_post_comments_audit.cursor_payload; Type: COMMENT; Schema: social; Owner: -
--

COMMENT ON COLUMN social.instagram_post_comments_audit.cursor_payload IS 'Sanitized final cursor envelope for the audited post; excludes cookies, headers, and secrets.';


--
-- Name: COLUMN instagram_post_comments_audit.comment_filter_param; Type: COMMENT; Schema: social; Owner: -
--

COMMENT ON COLUMN social.instagram_post_comments_audit.comment_filter_param IS 'Instagram comment filter mode used for the audited fetch.';


--
-- Name: instagram_post_payloads; Type: TABLE; Schema: social; Owner: -
--

CREATE TABLE social.instagram_post_payloads (
    post_id uuid NOT NULL,
    raw_data jsonb,
    asset_manifest jsonb DEFAULT '{}'::jsonb NOT NULL,
    child_posts_data jsonb DEFAULT '[]'::jsonb NOT NULL,
    payload_updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: instagram_profile_pagination_state; Type: TABLE; Schema: social; Owner: -
--

CREATE TABLE social.instagram_profile_pagination_state (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    run_id uuid,
    job_id text,
    account_handle text NOT NULL,
    source_scope text DEFAULT 'bravo'::text NOT NULL,
    direction text DEFAULT 'forward'::text NOT NULL,
    cursor_in text,
    end_cursor text,
    page_index integer DEFAULT 0 NOT NULL,
    posts_seen integer DEFAULT 0 NOT NULL,
    posts_upserted integer DEFAULT 0 NOT NULL,
    doc_id_used text,
    doc_ids_attempted jsonb DEFAULT '[]'::jsonb NOT NULL,
    proxy_fingerprint text,
    proxy_session_key text,
    stop_reason text,
    partial boolean DEFAULT true NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    CONSTRAINT instagram_profile_pagination_state_page_index_check CHECK ((page_index >= 0)),
    CONSTRAINT instagram_profile_pagination_state_posts_seen_check CHECK ((posts_seen >= 0)),
    CONSTRAINT instagram_profile_pagination_state_posts_upserted_check CHECK ((posts_upserted >= 0))
);


--
-- Name: TABLE instagram_profile_pagination_state; Type: COMMENT; Schema: social; Owner: -
--

COMMENT ON TABLE social.instagram_profile_pagination_state IS 'Resumable Instagram profile-post pagination checkpoints for Backfill Posts.';


--
-- Name: COLUMN instagram_profile_pagination_state.stop_reason; Type: COMMENT; Schema: social; Owner: -
--

COMMENT ON COLUMN social.instagram_profile_pagination_state.stop_reason IS 'Terminal or partial reason such as timeout_guard, cursor_expired_restart_required, pagination_doc_id_stale, or completed.';


--
-- Name: scrape_jobs; Type: TABLE; Schema: social; Owner: -
--

CREATE TABLE social.scrape_jobs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    run_id uuid,
    status text DEFAULT 'running'::text,
    worker_id text,
    config jsonb DEFAULT '{}'::jsonb,
    available_at timestamp with time zone DEFAULT now(),
    heartbeat_at timestamp with time zone,
    claimed_at timestamp with time zone,
    platform text DEFAULT 'instagram'::text,
    job_type text,
    metadata jsonb DEFAULT '{}'::jsonb,
    attempt_count integer DEFAULT 1,
    max_attempts integer DEFAULT 12,
    items_found integer DEFAULT 0,
    error_message text,
    started_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    season_id uuid,
    source_scope text DEFAULT 'network'::text,
    initiated_by text,
    last_error_code text,
    last_error_class text,
    last_error_at timestamp with time zone,
    priority integer DEFAULT 0,
    dedupe_key text,
    source_id text,
    show_id uuid,
    detail_dispatch_generation bigint DEFAULT 0 NOT NULL,
    detail_dispatch_token text,
    detail_dispatch_expires_at timestamp with time zone,
    detail_completion_receipt jsonb
);


--
-- Name: scrape_runs; Type: TABLE; Schema: social; Owner: -
--

CREATE TABLE social.scrape_runs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    status text DEFAULT 'running'::text,
    source_scope text,
    initiated_by text,
    config jsonb DEFAULT '{}'::jsonb,
    cancelled_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone,
    metadata jsonb DEFAULT '{}'::jsonb,
    platform text,
    total_jobs integer DEFAULT 0,
    completed_jobs integer DEFAULT 0,
    failed_jobs integer DEFAULT 0,
    active_jobs integer DEFAULT 0,
    items_found_total integer DEFAULT 0,
    stage_counts jsonb DEFAULT '{}'::jsonb,
    summary jsonb DEFAULT '{}'::jsonb,
    started_at timestamp with time zone,
    show_id uuid,
    season_id uuid
);


--
-- Name: scrape_workers; Type: TABLE; Schema: social; Owner: -
--

CREATE TABLE social.scrape_workers (
    worker_id text NOT NULL,
    stage text,
    status text DEFAULT 'idle'::text NOT NULL,
    run_id uuid,
    current_job_id uuid,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    supported_platforms text[],
    CONSTRAINT scrape_workers_status_check CHECK ((status = ANY (ARRAY['starting'::text, 'idle'::text, 'working'::text, 'stopped'::text])))
);


--
-- Name: COLUMN scrape_workers.supported_platforms; Type: COMMENT; Schema: social; Owner: -
--

COMMENT ON COLUMN social.scrape_workers.supported_platforms IS 'Platforms this worker can process. NULL = legacy worker (restricted to instagram/tiktok/twitter/youtube).';


--
-- Name: shared_account_sources; Type: TABLE; Schema: social; Owner: -
--

CREATE TABLE social.shared_account_sources (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    platform text NOT NULL,
    source_scope text DEFAULT 'network'::text NOT NULL,
    account_handle text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    scrape_priority integer DEFAULT 100 NOT NULL,
    metadata jsonb DEFAULT '{}'::jsonb NOT NULL,
    last_scrape_status text,
    last_scrape_run_id uuid,
    last_scrape_job_id uuid,
    last_scrape_at timestamp with time zone,
    last_classified_at timestamp with time zone,
    updated_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT shared_account_sources_platform_check CHECK ((platform = ANY (ARRAY['instagram'::text, 'tiktok'::text, 'youtube'::text, 'twitter'::text, 'facebook'::text, 'threads'::text]))),
    CONSTRAINT shared_account_sources_source_scope_check_v2 CHECK (((source_scope IS NULL) OR (source_scope = ANY (ARRAY['network'::text, 'creator'::text, 'community'::text, 'news'::text]))))
);


--
-- Name: social_post_entities; Type: TABLE; Schema: social; Owner: -
--

CREATE TABLE social.social_post_entities (
    platform text NOT NULL,
    entity_type text NOT NULL,
    entity_key text NOT NULL,
    entity_key_norm text NOT NULL,
    post_id uuid NOT NULL,
    entity_payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    first_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT social_post_entities_entity_key_check CHECK (((entity_key = btrim(entity_key)) AND (entity_key <> ''::text))),
    CONSTRAINT social_post_entities_entity_key_norm_check CHECK (((entity_key_norm = lower(btrim(entity_key_norm))) AND (entity_key_norm <> ''::text))),
    CONSTRAINT social_post_entities_entity_type_check CHECK ((entity_type = ANY (ARRAY['hashtag'::text, 'mention'::text, 'collaborator'::text, 'tagged_user'::text, 'location'::text, 'sound'::text, 'thread'::text, 'flair'::text, 'url'::text, 'external_id'::text]))),
    CONSTRAINT social_post_entities_platform_check CHECK ((platform = ANY (ARRAY['instagram'::text, 'tiktok'::text, 'twitter'::text, 'facebook'::text, 'threads'::text, 'youtube'::text, 'reddit'::text])))
);


--
-- Name: social_post_legacy_refs; Type: TABLE; Schema: social; Owner: -
--

CREATE TABLE social.social_post_legacy_refs (
    platform text NOT NULL,
    post_id uuid NOT NULL,
    legacy_schema text DEFAULT 'social'::text NOT NULL,
    legacy_table text NOT NULL,
    legacy_pk text NOT NULL,
    legacy_source_id text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT social_post_legacy_refs_legacy_pk_check CHECK (((legacy_pk = btrim(legacy_pk)) AND (legacy_pk <> ''::text))),
    CONSTRAINT social_post_legacy_refs_legacy_schema_check CHECK (((legacy_schema = btrim(legacy_schema)) AND (legacy_schema <> ''::text))),
    CONSTRAINT social_post_legacy_refs_legacy_source_id_check CHECK (((legacy_source_id = btrim(legacy_source_id)) AND (legacy_source_id <> ''::text))),
    CONSTRAINT social_post_legacy_refs_legacy_table_check CHECK (((legacy_table = btrim(legacy_table)) AND (legacy_table <> ''::text))),
    CONSTRAINT social_post_legacy_refs_platform_check CHECK ((platform = ANY (ARRAY['instagram'::text, 'tiktok'::text, 'twitter'::text, 'facebook'::text, 'threads'::text, 'youtube'::text, 'reddit'::text])))
);


--
-- Name: social_post_media_assets; Type: TABLE; Schema: social; Owner: -
--

CREATE TABLE social.social_post_media_assets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    platform text NOT NULL,
    post_id uuid NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    media_type text,
    source_url text,
    hosted_url text,
    thumbnail_url text,
    hosted_thumbnail_url text,
    width integer,
    height integer,
    duration_seconds integer,
    mirror_status text,
    mirror_error text,
    mirror_last_attempt_at timestamp with time zone,
    media_payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT social_post_media_assets_duration_seconds_check CHECK (((duration_seconds IS NULL) OR (duration_seconds >= 0))),
    CONSTRAINT social_post_media_assets_height_check CHECK (((height IS NULL) OR (height >= 0))),
    CONSTRAINT social_post_media_assets_platform_check CHECK ((platform = ANY (ARRAY['instagram'::text, 'tiktok'::text, 'twitter'::text, 'facebook'::text, 'threads'::text, 'youtube'::text, 'reddit'::text]))),
    CONSTRAINT social_post_media_assets_position_check CHECK (("position" >= 0)),
    CONSTRAINT social_post_media_assets_width_check CHECK (((width IS NULL) OR (width >= 0)))
);


--
-- Name: social_post_observations; Type: TABLE; Schema: social; Owner: -
--

CREATE TABLE social.social_post_observations (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    platform text NOT NULL,
    post_id uuid NOT NULL,
    source_table text NOT NULL,
    source_pk text,
    source_url text,
    scrape_run_id uuid,
    observed_at timestamp with time zone DEFAULT now() NOT NULL,
    raw_payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    normalized_payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    detail_run_id uuid,
    detail_source_id text,
    CONSTRAINT social_post_observations_platform_check CHECK ((platform = ANY (ARRAY['instagram'::text, 'tiktok'::text, 'twitter'::text, 'facebook'::text, 'threads'::text, 'youtube'::text, 'reddit'::text]))),
    CONSTRAINT social_post_observations_source_table_check CHECK (((source_table = btrim(source_table)) AND (source_table <> ''::text)))
);


--
-- Name: social_posts; Type: TABLE; Schema: social; Owner: -
--

CREATE TABLE social.social_posts (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    platform text NOT NULL,
    source_id text NOT NULL,
    owner_handle text,
    owner_handle_norm text,
    owner_id text,
    canonical_url text,
    title text,
    body text,
    media_type text,
    posted_at timestamp with time zone,
    like_count bigint DEFAULT 0 NOT NULL,
    comment_count bigint DEFAULT 0 NOT NULL,
    share_count bigint DEFAULT 0 NOT NULL,
    view_count bigint DEFAULT 0 NOT NULL,
    save_count bigint DEFAULT 0 NOT NULL,
    quote_count bigint DEFAULT 0 NOT NULL,
    first_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    last_seen_at timestamp with time zone DEFAULT now() NOT NULL,
    last_scraped_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT social_posts_comment_count_check CHECK ((comment_count >= 0)),
    CONSTRAINT social_posts_like_count_check CHECK ((like_count >= 0)),
    CONSTRAINT social_posts_owner_handle_norm_check CHECK (((owner_handle_norm IS NULL) OR (owner_handle_norm = lower(btrim(owner_handle_norm))))),
    CONSTRAINT social_posts_platform_check CHECK ((platform = ANY (ARRAY['instagram'::text, 'tiktok'::text, 'twitter'::text, 'facebook'::text, 'threads'::text, 'youtube'::text, 'reddit'::text]))),
    CONSTRAINT social_posts_quote_count_check CHECK ((quote_count >= 0)),
    CONSTRAINT social_posts_save_count_check CHECK ((save_count >= 0)),
    CONSTRAINT social_posts_share_count_check CHECK ((share_count >= 0)),
    CONSTRAINT social_posts_source_id_check CHECK (((source_id = btrim(source_id)) AND (source_id <> ''::text))),
    CONSTRAINT social_posts_view_count_check CHECK ((view_count >= 0))
);


--
-- Name: episodes episodes_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.episodes
    ADD CONSTRAINT episodes_pkey PRIMARY KEY (id);


--
-- Name: people people_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.people
    ADD CONSTRAINT people_pkey PRIMARY KEY (id);


--
-- Name: seasons seasons_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.seasons
    ADD CONSTRAINT seasons_pkey PRIMARY KEY (id);


--
-- Name: shows shows_pkey; Type: CONSTRAINT; Schema: core; Owner: -
--

ALTER TABLE ONLY core.shows
    ADD CONSTRAINT shows_pkey PRIMARY KEY (id);


--
-- Name: application_versions application_versions_pkey; Type: CONSTRAINT; Schema: dbos; Owner: -
--

ALTER TABLE ONLY dbos.application_versions
    ADD CONSTRAINT application_versions_pkey PRIMARY KEY (version_id);


--
-- Name: application_versions application_versions_version_name_key; Type: CONSTRAINT; Schema: dbos; Owner: -
--

ALTER TABLE ONLY dbos.application_versions
    ADD CONSTRAINT application_versions_version_name_key UNIQUE (version_name);


--
-- Name: dbos_migrations dbos_migrations_pkey; Type: CONSTRAINT; Schema: dbos; Owner: -
--

ALTER TABLE ONLY dbos.dbos_migrations
    ADD CONSTRAINT dbos_migrations_pkey PRIMARY KEY (version);


--
-- Name: event_dispatch_kv event_dispatch_kv_pkey; Type: CONSTRAINT; Schema: dbos; Owner: -
--

ALTER TABLE ONLY dbos.event_dispatch_kv
    ADD CONSTRAINT event_dispatch_kv_pkey PRIMARY KEY (service_name, workflow_fn_name, key);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: dbos; Owner: -
--

ALTER TABLE ONLY dbos.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (message_uuid);


--
-- Name: operation_outputs operation_outputs_pkey; Type: CONSTRAINT; Schema: dbos; Owner: -
--

ALTER TABLE ONLY dbos.operation_outputs
    ADD CONSTRAINT operation_outputs_pkey PRIMARY KEY (workflow_uuid, function_id);


--
-- Name: queues queues_name_key; Type: CONSTRAINT; Schema: dbos; Owner: -
--

ALTER TABLE ONLY dbos.queues
    ADD CONSTRAINT queues_name_key UNIQUE (name);


--
-- Name: queues queues_pkey; Type: CONSTRAINT; Schema: dbos; Owner: -
--

ALTER TABLE ONLY dbos.queues
    ADD CONSTRAINT queues_pkey PRIMARY KEY (queue_id);


--
-- Name: streams streams_pkey; Type: CONSTRAINT; Schema: dbos; Owner: -
--

ALTER TABLE ONLY dbos.streams
    ADD CONSTRAINT streams_pkey PRIMARY KEY (workflow_uuid, key, "offset");


--
-- Name: workflow_events_history workflow_events_history_pkey; Type: CONSTRAINT; Schema: dbos; Owner: -
--

ALTER TABLE ONLY dbos.workflow_events_history
    ADD CONSTRAINT workflow_events_history_pkey PRIMARY KEY (workflow_uuid, function_id, key);


--
-- Name: workflow_events workflow_events_pkey; Type: CONSTRAINT; Schema: dbos; Owner: -
--

ALTER TABLE ONLY dbos.workflow_events
    ADD CONSTRAINT workflow_events_pkey PRIMARY KEY (workflow_uuid, key);


--
-- Name: workflow_input workflow_input_pkey; Type: CONSTRAINT; Schema: dbos; Owner: -
--

ALTER TABLE ONLY dbos.workflow_input
    ADD CONSTRAINT workflow_input_pkey PRIMARY KEY (workflow_uuid);


--
-- Name: workflow_output workflow_output_pkey; Type: CONSTRAINT; Schema: dbos; Owner: -
--

ALTER TABLE ONLY dbos.workflow_output
    ADD CONSTRAINT workflow_output_pkey PRIMARY KEY (workflow_uuid);


--
-- Name: workflow_schedules workflow_schedules_pkey; Type: CONSTRAINT; Schema: dbos; Owner: -
--

ALTER TABLE ONLY dbos.workflow_schedules
    ADD CONSTRAINT workflow_schedules_pkey PRIMARY KEY (schedule_id);


--
-- Name: workflow_schedules workflow_schedules_schedule_name_key; Type: CONSTRAINT; Schema: dbos; Owner: -
--

ALTER TABLE ONLY dbos.workflow_schedules
    ADD CONSTRAINT workflow_schedules_schedule_name_key UNIQUE (schedule_name);


--
-- Name: workflow_status workflow_status_pkey; Type: CONSTRAINT; Schema: dbos; Owner: -
--

ALTER TABLE ONLY dbos.workflow_status
    ADD CONSTRAINT workflow_status_pkey PRIMARY KEY (workflow_uuid);


--
-- Name: account_auth_cooldown account_auth_cooldown_pkey; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.account_auth_cooldown
    ADD CONSTRAINT account_auth_cooldown_pkey PRIMARY KEY (platform, account_handle);


--
-- Name: avatar_registry avatar_registry_pkey; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.avatar_registry
    ADD CONSTRAINT avatar_registry_pkey PRIMARY KEY (id);


--
-- Name: avatar_registry avatar_registry_platform_account_handle_source_url_key; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.avatar_registry
    ADD CONSTRAINT avatar_registry_platform_account_handle_source_url_key UNIQUE (platform, account_handle, source_url);


--
-- Name: ig_comment_rate_pace ig_comment_rate_pace_pkey; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.ig_comment_rate_pace
    ADD CONSTRAINT ig_comment_rate_pace_pkey PRIMARY KEY (rate_key);


--
-- Name: instagram_account_catalog_post_collaborators instagram_account_catalog_post_collaborators_pkey; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_account_catalog_post_collaborators
    ADD CONSTRAINT instagram_account_catalog_post_collaborators_pkey PRIMARY KEY (catalog_post_id, collaborator_handle);


--
-- Name: instagram_account_catalog_post_payloads instagram_account_catalog_post_payloads_pkey; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_account_catalog_post_payloads
    ADD CONSTRAINT instagram_account_catalog_post_payloads_pkey PRIMARY KEY (catalog_post_id);


--
-- Name: instagram_account_catalog_posts instagram_account_catalog_posts_pkey; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_account_catalog_posts
    ADD CONSTRAINT instagram_account_catalog_posts_pkey PRIMARY KEY (id);


--
-- Name: instagram_account_catalog_posts instagram_account_catalog_posts_source_id_key; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_account_catalog_posts
    ADD CONSTRAINT instagram_account_catalog_posts_source_id_key UNIQUE (source_id);


--
-- Name: instagram_comments instagram_comments_cursor_param_check; Type: CHECK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE social.instagram_comments
    ADD CONSTRAINT instagram_comments_cursor_param_check CHECK (((cursor_param IS NULL) OR (cursor_param = ANY (ARRAY['min_id'::text, 'max_id'::text, 'cached_comments_cursor'::text, 'bifilter_token'::text, 'tao_cursor'::text])))) NOT VALID;


--
-- Name: instagram_comments instagram_comments_phase_check; Type: CHECK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE social.instagram_comments
    ADD CONSTRAINT instagram_comments_phase_check CHECK (((phase IS NULL) OR (phase = ANY (ARRAY['ranked'::text, 'headload'::text, 'fb_crosspost'::text, 'child'::text])))) NOT VALID;


--
-- Name: instagram_comments instagram_comments_pkey; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_comments
    ADD CONSTRAINT instagram_comments_pkey PRIMARY KEY (id);


--
-- Name: instagram_comments instagram_comments_post_id_comment_id_key; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_comments
    ADD CONSTRAINT instagram_comments_post_id_comment_id_key UNIQUE (post_id, comment_id);


--
-- Name: instagram_detail_request_lanes instagram_detail_request_lanes_pkey; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_detail_request_lanes
    ADD CONSTRAINT instagram_detail_request_lanes_pkey PRIMARY KEY (identity_key);


--
-- Name: instagram_detail_run_targets instagram_detail_run_targets_pkey; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_detail_run_targets
    ADD CONSTRAINT instagram_detail_run_targets_pkey PRIMARY KEY (run_id, source_id);


--
-- Name: instagram_detail_run_targets instagram_detail_run_targets_run_id_target_key_key; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_detail_run_targets
    ADD CONSTRAINT instagram_detail_run_targets_run_id_target_key_key UNIQUE (run_id, target_key);


--
-- Name: instagram_ingestion_commands instagram_ingestion_commands_pkey; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_ingestion_commands
    ADD CONSTRAINT instagram_ingestion_commands_pkey PRIMARY KEY (account, idempotency_key);


--
-- Name: instagram_ingestion_comment_pages instagram_ingestion_comment_pages_evidence_id_key; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_ingestion_comment_pages
    ADD CONSTRAINT instagram_ingestion_comment_pages_evidence_id_key UNIQUE (evidence_id);


--
-- Name: instagram_ingestion_comment_pages instagram_ingestion_comment_pages_pkey; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_ingestion_comment_pages
    ADD CONSTRAINT instagram_ingestion_comment_pages_pkey PRIMARY KEY (page_id);


--
-- Name: instagram_ingestion_decisions instagram_ingestion_decisions_pkey; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_ingestion_decisions
    ADD CONSTRAINT instagram_ingestion_decisions_pkey PRIMARY KEY (execution_id, ordinal);


--
-- Name: instagram_ingestion_discovery_pages instagram_ingestion_discovery_pages_pkey; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_ingestion_discovery_pages
    ADD CONSTRAINT instagram_ingestion_discovery_pages_pkey PRIMARY KEY (run_id, stage, page_id);


--
-- Name: instagram_ingestion_dispatches instagram_ingestion_dispatches_pkey; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_ingestion_dispatches
    ADD CONSTRAINT instagram_ingestion_dispatches_pkey PRIMARY KEY (owner_token);


--
-- Name: instagram_ingestion_evidence instagram_ingestion_evidence_evidence_id_run_id_stage_targe_key; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_ingestion_evidence
    ADD CONSTRAINT instagram_ingestion_evidence_evidence_id_run_id_stage_targe_key UNIQUE (evidence_id, run_id, stage, target_key);


--
-- Name: instagram_ingestion_evidence instagram_ingestion_evidence_pkey; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_ingestion_evidence
    ADD CONSTRAINT instagram_ingestion_evidence_pkey PRIMARY KEY (evidence_id);


--
-- Name: instagram_ingestion_manifests instagram_ingestion_manifests_pkey; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_ingestion_manifests
    ADD CONSTRAINT instagram_ingestion_manifests_pkey PRIMARY KEY (run_id, stage);


--
-- Name: instagram_ingestion_outbox instagram_ingestion_outbox_pkey; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_ingestion_outbox
    ADD CONSTRAINT instagram_ingestion_outbox_pkey PRIMARY KEY (execution_id);


--
-- Name: instagram_ingestion_outbox instagram_ingestion_outbox_run_id_generation_key; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_ingestion_outbox
    ADD CONSTRAINT instagram_ingestion_outbox_run_id_generation_key UNIQUE (run_id, generation);


--
-- Name: instagram_ingestion_partitions instagram_ingestion_partition_run_id_generation_partition_n_key; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_ingestion_partitions
    ADD CONSTRAINT instagram_ingestion_partition_run_id_generation_partition_n_key UNIQUE (run_id, generation, partition_number);


--
-- Name: instagram_ingestion_partitions instagram_ingestion_partitions_pkey; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_ingestion_partitions
    ADD CONSTRAINT instagram_ingestion_partitions_pkey PRIMARY KEY (execution_id);


--
-- Name: instagram_ingestion_receipts instagram_ingestion_receipts_pkey; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_ingestion_receipts
    ADD CONSTRAINT instagram_ingestion_receipts_pkey PRIMARY KEY (receipt_id);


--
-- Name: instagram_ingestion_receipts instagram_ingestion_receipts_run_id_stage_target_key_owner__key; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_ingestion_receipts
    ADD CONSTRAINT instagram_ingestion_receipts_run_id_stage_target_key_owner__key UNIQUE (run_id, stage, target_key, owner_generation);


--
-- Name: instagram_ingestion_runs instagram_ingestion_runs_pkey; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_ingestion_runs
    ADD CONSTRAINT instagram_ingestion_runs_pkey PRIMARY KEY (run_id);


--
-- Name: instagram_ingestion_targets instagram_ingestion_targets_pkey; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_ingestion_targets
    ADD CONSTRAINT instagram_ingestion_targets_pkey PRIMARY KEY (run_id, stage, target_key);


--
-- Name: instagram_post_comments_audit instagram_post_comments_audit_pkey; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_post_comments_audit
    ADD CONSTRAINT instagram_post_comments_audit_pkey PRIMARY KEY (id);


--
-- Name: instagram_post_payloads instagram_post_payloads_pkey; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_post_payloads
    ADD CONSTRAINT instagram_post_payloads_pkey PRIMARY KEY (post_id);


--
-- Name: instagram_posts instagram_posts_pkey; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_posts
    ADD CONSTRAINT instagram_posts_pkey PRIMARY KEY (id);


--
-- Name: instagram_posts instagram_posts_shortcode_key; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_posts
    ADD CONSTRAINT instagram_posts_shortcode_key UNIQUE (shortcode);


--
-- Name: instagram_profile_pagination_state instagram_profile_pagination_state_pkey; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_profile_pagination_state
    ADD CONSTRAINT instagram_profile_pagination_state_pkey PRIMARY KEY (id);


--
-- Name: scrape_jobs scrape_jobs_pkey; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.scrape_jobs
    ADD CONSTRAINT scrape_jobs_pkey PRIMARY KEY (id);


--
-- Name: scrape_runs scrape_runs_pkey; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.scrape_runs
    ADD CONSTRAINT scrape_runs_pkey PRIMARY KEY (id);


--
-- Name: scrape_workers scrape_workers_pkey; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.scrape_workers
    ADD CONSTRAINT scrape_workers_pkey PRIMARY KEY (worker_id);


--
-- Name: shared_account_sources shared_account_sources_pkey; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.shared_account_sources
    ADD CONSTRAINT shared_account_sources_pkey PRIMARY KEY (id);


--
-- Name: shared_account_sources shared_account_sources_platform_source_scope_account_handle_key; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.shared_account_sources
    ADD CONSTRAINT shared_account_sources_platform_source_scope_account_handle_key UNIQUE (platform, source_scope, account_handle);


--
-- Name: social_post_entities social_post_entities_pkey; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.social_post_entities
    ADD CONSTRAINT social_post_entities_pkey PRIMARY KEY (platform, entity_type, entity_key_norm, post_id);


--
-- Name: social_post_legacy_refs social_post_legacy_refs_pkey; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.social_post_legacy_refs
    ADD CONSTRAINT social_post_legacy_refs_pkey PRIMARY KEY (platform, legacy_table, legacy_pk);


--
-- Name: social_post_legacy_refs social_post_legacy_refs_platform_legacy_table_legacy_source_key; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.social_post_legacy_refs
    ADD CONSTRAINT social_post_legacy_refs_platform_legacy_table_legacy_source_key UNIQUE (platform, legacy_table, legacy_source_id);


--
-- Name: social_post_media_assets social_post_media_assets_pkey; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.social_post_media_assets
    ADD CONSTRAINT social_post_media_assets_pkey PRIMARY KEY (id);


--
-- Name: social_post_media_assets social_post_media_assets_platform_post_id_position_key; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.social_post_media_assets
    ADD CONSTRAINT social_post_media_assets_platform_post_id_position_key UNIQUE (platform, post_id, "position");


--
-- Name: social_post_observations social_post_observations_pkey; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.social_post_observations
    ADD CONSTRAINT social_post_observations_pkey PRIMARY KEY (id);


--
-- Name: social_posts social_posts_pkey; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.social_posts
    ADD CONSTRAINT social_posts_pkey PRIMARY KEY (id);


--
-- Name: social_posts social_posts_platform_id_key; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.social_posts
    ADD CONSTRAINT social_posts_platform_id_key UNIQUE (platform, id);


--
-- Name: social_posts social_posts_platform_source_id_key; Type: CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.social_posts
    ADD CONSTRAINT social_posts_platform_source_id_key UNIQUE (platform, source_id);


--
-- Name: idx_operation_outputs_completed_at_function_name_v2; Type: INDEX; Schema: dbos; Owner: -
--

CREATE INDEX idx_operation_outputs_completed_at_function_name_v2 ON dbos.operation_outputs USING btree (completed_at_epoch_ms, function_name) INCLUDE (application_name);


--
-- Name: idx_operation_outputs_retention; Type: INDEX; Schema: dbos; Owner: -
--

CREATE INDEX idx_operation_outputs_retention ON dbos.operation_outputs USING btree (retention_timestamp);


--
-- Name: idx_workflow_input_retention; Type: INDEX; Schema: dbos; Owner: -
--

CREATE INDEX idx_workflow_input_retention ON dbos.workflow_input USING btree (retention_timestamp);


--
-- Name: idx_workflow_output_retention; Type: INDEX; Schema: dbos; Owner: -
--

CREATE INDEX idx_workflow_output_retention ON dbos.workflow_output USING btree (retention_timestamp);


--
-- Name: idx_workflow_status_attributes; Type: INDEX; Schema: dbos; Owner: -
--

CREATE INDEX idx_workflow_status_attributes ON dbos.workflow_status USING gin (attributes) WHERE (attributes IS NOT NULL);


--
-- Name: idx_workflow_status_completed_at; Type: INDEX; Schema: dbos; Owner: -
--

CREATE INDEX idx_workflow_status_completed_at ON dbos.workflow_status USING btree (completed_at) WHERE (completed_at IS NOT NULL);


--
-- Name: idx_workflow_status_deadline; Type: INDEX; Schema: dbos; Owner: -
--

CREATE INDEX idx_workflow_status_deadline ON dbos.workflow_status USING btree (workflow_deadline_epoch_ms) WHERE ((status = ANY (ARRAY['ENQUEUED'::text, 'PENDING'::text, 'DELAYED'::text])) AND (workflow_deadline_epoch_ms IS NOT NULL));


--
-- Name: idx_workflow_status_delayed; Type: INDEX; Schema: dbos; Owner: -
--

CREATE INDEX idx_workflow_status_delayed ON dbos.workflow_status USING btree (delay_until_epoch_ms) WHERE (status = 'DELAYED'::text);


--
-- Name: idx_workflow_status_failed; Type: INDEX; Schema: dbos; Owner: -
--

CREATE INDEX idx_workflow_status_failed ON dbos.workflow_status USING btree (status, created_at) WHERE (status = ANY (ARRAY['ERROR'::text, 'CANCELLED'::text, 'MAX_RECOVERY_ATTEMPTS_EXCEEDED'::text]));


--
-- Name: idx_workflow_status_forked_from; Type: INDEX; Schema: dbos; Owner: -
--

CREATE INDEX idx_workflow_status_forked_from ON dbos.workflow_status USING btree (forked_from) WHERE (forked_from IS NOT NULL);


--
-- Name: idx_workflow_status_in_flight_v2; Type: INDEX; Schema: dbos; Owner: -
--

CREATE INDEX idx_workflow_status_in_flight_v2 ON dbos.workflow_status USING btree (queue_name, status, priority, created_at) INCLUDE (application_name) WHERE (status = ANY (ARRAY['ENQUEUED'::text, 'PENDING'::text]));


--
-- Name: idx_workflow_status_parent_workflow_id; Type: INDEX; Schema: dbos; Owner: -
--

CREATE INDEX idx_workflow_status_parent_workflow_id ON dbos.workflow_status USING btree (parent_workflow_id) WHERE (parent_workflow_id IS NOT NULL);


--
-- Name: idx_workflow_status_partition_dequeue_v3; Type: INDEX; Schema: dbos; Owner: -
--

CREATE INDEX idx_workflow_status_partition_dequeue_v3 ON dbos.workflow_status USING btree (queue_name, status, queue_partition_key, priority, created_at, workflow_uuid) INCLUDE (application_name) WHERE ((status = ANY (ARRAY['ENQUEUED'::text, 'PENDING'::text])) AND (queue_partition_key IS NOT NULL));


--
-- Name: idx_workflow_status_pending; Type: INDEX; Schema: dbos; Owner: -
--

CREATE INDEX idx_workflow_status_pending ON dbos.workflow_status USING btree (created_at) WHERE (status = 'PENDING'::text);


--
-- Name: idx_workflow_status_rate_limited; Type: INDEX; Schema: dbos; Owner: -
--

CREATE INDEX idx_workflow_status_rate_limited ON dbos.workflow_status USING btree (queue_name, started_at_epoch_ms) WHERE (rate_limited = true);


--
-- Name: idx_workflow_status_schedule_name; Type: INDEX; Schema: dbos; Owner: -
--

CREATE INDEX idx_workflow_status_schedule_name ON dbos.workflow_status USING btree (schedule_name) WHERE (schedule_name IS NOT NULL);


--
-- Name: idx_workflow_status_started_at; Type: INDEX; Schema: dbos; Owner: -
--

CREATE INDEX idx_workflow_status_started_at ON dbos.workflow_status USING btree (started_at_epoch_ms) WHERE (started_at_epoch_ms IS NOT NULL);


--
-- Name: idx_workflow_topic; Type: INDEX; Schema: dbos; Owner: -
--

CREATE INDEX idx_workflow_topic ON dbos.notifications USING btree (destination_uuid, topic);


--
-- Name: uq_application_versions_owner_version; Type: INDEX; Schema: dbos; Owner: -
--

CREATE UNIQUE INDEX uq_application_versions_owner_version ON dbos.application_versions USING btree (application_name, version_name) WHERE (application_name IS NOT NULL);


--
-- Name: uq_application_versions_unclaimed_version; Type: INDEX; Schema: dbos; Owner: -
--

CREATE UNIQUE INDEX uq_application_versions_unclaimed_version ON dbos.application_versions USING btree (version_name) WHERE (application_name IS NULL);


--
-- Name: uq_workflow_status_dedup_id; Type: INDEX; Schema: dbos; Owner: -
--

CREATE UNIQUE INDEX uq_workflow_status_dedup_id ON dbos.workflow_status USING btree (queue_name, deduplication_id) WHERE (deduplication_id IS NOT NULL);


--
-- Name: workflow_status_created_at_index; Type: INDEX; Schema: dbos; Owner: -
--

CREATE INDEX workflow_status_created_at_index ON dbos.workflow_status USING btree (created_at);


--
-- Name: account_auth_cooldown_active_idx; Type: INDEX; Schema: social; Owner: -
--

CREATE INDEX account_auth_cooldown_active_idx ON social.account_auth_cooldown USING btree (platform, cooldown_until) WHERE (cooldown_until IS NOT NULL);


--
-- Name: instagram_comments_post_child_count_idx; Type: INDEX; Schema: social; Owner: -
--

CREATE INDEX instagram_comments_post_child_count_idx ON social.instagram_comments USING btree (post_id, child_comment_count) WHERE (child_comment_count > 0);


--
-- Name: instagram_comments_post_covered_status_idx; Type: INDEX; Schema: social; Owner: -
--

CREATE INDEX instagram_comments_post_covered_status_idx ON social.instagram_comments USING btree (post_id) WHERE (is_covered OR (status <> 'Active'::text));


--
-- Name: instagram_comments_post_phase_comment_index_idx; Type: INDEX; Schema: social; Owner: -
--

CREATE INDEX instagram_comments_post_phase_comment_index_idx ON social.instagram_comments USING btree (post_id, phase, comment_index);


--
-- Name: instagram_detail_targets_lease_idx; Type: INDEX; Schema: social; Owner: -
--

CREATE INDEX instagram_detail_targets_lease_idx ON social.instagram_detail_run_targets USING btree (lease_expires_at) WHERE (state = 'leased'::text);


--
-- Name: instagram_detail_targets_ready_idx; Type: INDEX; Schema: social; Owner: -
--

CREATE INDEX instagram_detail_targets_ready_idx ON social.instagram_detail_run_targets USING btree (run_id, state, next_attempt_at, target_key);


--
-- Name: instagram_ingestion_comment_pages_target_idx; Type: INDEX; Schema: social; Owner: -
--

CREATE INDEX instagram_ingestion_comment_pages_target_idx ON social.instagram_ingestion_comment_pages USING btree (run_id, target_key, committed_at);


--
-- Name: instagram_ingestion_dispatches_target_idx; Type: INDEX; Schema: social; Owner: -
--

CREATE INDEX instagram_ingestion_dispatches_target_idx ON social.instagram_ingestion_dispatches USING btree (run_id, stage, target_key, created_at DESC);


--
-- Name: instagram_ingestion_evidence_expiry_idx; Type: INDEX; Schema: social; Owner: -
--

CREATE INDEX instagram_ingestion_evidence_expiry_idx ON social.instagram_ingestion_evidence USING btree (expires_at) WHERE (payload IS NOT NULL);


--
-- Name: instagram_ingestion_outbox_pending_idx; Type: INDEX; Schema: social; Owner: -
--

CREATE INDEX instagram_ingestion_outbox_pending_idx ON social.instagram_ingestion_outbox USING btree (available_at) WHERE (acknowledged_at IS NULL);


--
-- Name: instagram_ingestion_partitions_pending_idx; Type: INDEX; Schema: social; Owner: -
--

CREATE INDEX instagram_ingestion_partitions_pending_idx ON social.instagram_ingestion_partitions USING btree (available_at) WHERE (acknowledged_at IS NULL);


--
-- Name: instagram_ingestion_runs_account_idx; Type: INDEX; Schema: social; Owner: -
--

CREATE INDEX instagram_ingestion_runs_account_idx ON social.instagram_ingestion_runs USING btree (account, created_at DESC);


--
-- Name: instagram_ingestion_targets_ordered_idx; Type: INDEX; Schema: social; Owner: -
--

CREATE INDEX instagram_ingestion_targets_ordered_idx ON social.instagram_ingestion_targets USING btree (run_id, stage, target_key) WHERE (outcome = 'unresolved'::text);


--
-- Name: instagram_ingestion_targets_ready_idx; Type: INDEX; Schema: social; Owner: -
--

CREATE INDEX instagram_ingestion_targets_ready_idx ON social.instagram_ingestion_targets USING btree (run_id, stage, next_attempt_at) WHERE (outcome = 'unresolved'::text);


--
-- Name: instagram_post_comments_audit_post_created_idx; Type: INDEX; Schema: social; Owner: -
--

CREATE INDEX instagram_post_comments_audit_post_created_idx ON social.instagram_post_comments_audit USING btree (post_id, created_at DESC);


--
-- Name: instagram_post_comments_audit_run_job_created_idx; Type: INDEX; Schema: social; Owner: -
--

CREATE INDEX instagram_post_comments_audit_run_job_created_idx ON social.instagram_post_comments_audit USING btree (scrape_run_id, scrape_job_id, created_at DESC) WHERE ((scrape_run_id IS NOT NULL) OR (scrape_job_id IS NOT NULL));


--
-- Name: instagram_profile_pagination_state_account_updated_idx; Type: INDEX; Schema: social; Owner: -
--

CREATE INDEX instagram_profile_pagination_state_account_updated_idx ON social.instagram_profile_pagination_state USING btree (lower(account_handle), source_scope, updated_at DESC);


--
-- Name: instagram_profile_pagination_state_active_key; Type: INDEX; Schema: social; Owner: -
--

CREATE UNIQUE INDEX instagram_profile_pagination_state_active_key ON social.instagram_profile_pagination_state USING btree (run_id, lower(account_handle), source_scope, direction) WHERE (completed_at IS NULL);


--
-- Name: instagram_profile_pagination_state_run_updated_idx; Type: INDEX; Schema: social; Owner: -
--

CREATE INDEX instagram_profile_pagination_state_run_updated_idx ON social.instagram_profile_pagination_state USING btree (run_id, updated_at DESC);


--
-- Name: scrape_workers_status_seen_idx; Type: INDEX; Schema: social; Owner: -
--

CREATE INDEX scrape_workers_status_seen_idx ON social.scrape_workers USING btree (status, last_seen_at DESC);


--
-- Name: shared_account_sources_active_idx; Type: INDEX; Schema: social; Owner: -
--

CREATE INDEX shared_account_sources_active_idx ON social.shared_account_sources USING btree (source_scope, is_active, platform, scrape_priority, account_handle);


--
-- Name: social_post_observations_detail_target_idx; Type: INDEX; Schema: social; Owner: -
--

CREATE UNIQUE INDEX social_post_observations_detail_target_idx ON social.social_post_observations USING btree (detail_run_id, detail_source_id) WHERE (detail_run_id IS NOT NULL);


--
-- Name: notifications dbos_notifications_trigger; Type: TRIGGER; Schema: dbos; Owner: -
--

CREATE TRIGGER dbos_notifications_trigger AFTER INSERT ON dbos.notifications FOR EACH ROW EXECUTE FUNCTION dbos.notifications_function();


--
-- Name: notifications notifications_destination_uuid_fkey; Type: FK CONSTRAINT; Schema: dbos; Owner: -
--

ALTER TABLE ONLY dbos.notifications
    ADD CONSTRAINT notifications_destination_uuid_fkey FOREIGN KEY (destination_uuid) REFERENCES dbos.workflow_status(workflow_uuid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: streams streams_workflow_uuid_fkey; Type: FK CONSTRAINT; Schema: dbos; Owner: -
--

ALTER TABLE ONLY dbos.streams
    ADD CONSTRAINT streams_workflow_uuid_fkey FOREIGN KEY (workflow_uuid) REFERENCES dbos.workflow_status(workflow_uuid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: workflow_events_history workflow_events_history_workflow_uuid_fkey; Type: FK CONSTRAINT; Schema: dbos; Owner: -
--

ALTER TABLE ONLY dbos.workflow_events_history
    ADD CONSTRAINT workflow_events_history_workflow_uuid_fkey FOREIGN KEY (workflow_uuid) REFERENCES dbos.workflow_status(workflow_uuid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: workflow_events workflow_events_workflow_uuid_fkey; Type: FK CONSTRAINT; Schema: dbos; Owner: -
--

ALTER TABLE ONLY dbos.workflow_events
    ADD CONSTRAINT workflow_events_workflow_uuid_fkey FOREIGN KEY (workflow_uuid) REFERENCES dbos.workflow_status(workflow_uuid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: instagram_account_catalog_post_collaborators instagram_account_catalog_post_collaborato_catalog_post_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_account_catalog_post_collaborators
    ADD CONSTRAINT instagram_account_catalog_post_collaborato_catalog_post_id_fkey FOREIGN KEY (catalog_post_id) REFERENCES social.instagram_account_catalog_posts(id) ON DELETE CASCADE;


--
-- Name: instagram_account_catalog_post_payloads instagram_account_catalog_post_payloads_catalog_post_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_account_catalog_post_payloads
    ADD CONSTRAINT instagram_account_catalog_post_payloads_catalog_post_id_fkey FOREIGN KEY (catalog_post_id) REFERENCES social.instagram_account_catalog_posts(id) ON DELETE CASCADE;


--
-- Name: instagram_account_catalog_posts instagram_account_catalog_posts_assigned_season_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_account_catalog_posts
    ADD CONSTRAINT instagram_account_catalog_posts_assigned_season_id_fkey FOREIGN KEY (assigned_season_id) REFERENCES core.seasons(id) ON DELETE SET NULL;


--
-- Name: instagram_account_catalog_posts instagram_account_catalog_posts_assigned_show_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_account_catalog_posts
    ADD CONSTRAINT instagram_account_catalog_posts_assigned_show_id_fkey FOREIGN KEY (assigned_show_id) REFERENCES core.shows(id) ON DELETE SET NULL;


--
-- Name: instagram_account_catalog_posts instagram_account_catalog_posts_last_backfill_run_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_account_catalog_posts
    ADD CONSTRAINT instagram_account_catalog_posts_last_backfill_run_id_fkey FOREIGN KEY (last_backfill_run_id) REFERENCES social.scrape_runs(id) ON DELETE SET NULL;


--
-- Name: instagram_comments instagram_comments_job_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_comments
    ADD CONSTRAINT instagram_comments_job_id_fkey FOREIGN KEY (job_id) REFERENCES social.scrape_jobs(id) ON DELETE SET NULL;


--
-- Name: instagram_comments instagram_comments_last_seen_run_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_comments
    ADD CONSTRAINT instagram_comments_last_seen_run_id_fkey FOREIGN KEY (last_seen_run_id) REFERENCES social.scrape_runs(id) ON DELETE SET NULL;


--
-- Name: instagram_comments instagram_comments_parent_comment_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_comments
    ADD CONSTRAINT instagram_comments_parent_comment_id_fkey FOREIGN KEY (parent_comment_id) REFERENCES social.instagram_comments(id) ON DELETE CASCADE;


--
-- Name: instagram_comments instagram_comments_post_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_comments
    ADD CONSTRAINT instagram_comments_post_id_fkey FOREIGN KEY (post_id) REFERENCES social.instagram_posts(id) ON DELETE CASCADE;


--
-- Name: instagram_comments instagram_comments_root_comment_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_comments
    ADD CONSTRAINT instagram_comments_root_comment_id_fkey FOREIGN KEY (root_comment_id) REFERENCES social.instagram_comments(id) ON DELETE SET NULL;


--
-- Name: instagram_comments instagram_comments_season_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_comments
    ADD CONSTRAINT instagram_comments_season_id_fkey FOREIGN KEY (season_id) REFERENCES core.seasons(id) ON DELETE SET NULL;


--
-- Name: instagram_detail_run_targets instagram_detail_run_targets_lease_job_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_detail_run_targets
    ADD CONSTRAINT instagram_detail_run_targets_lease_job_id_fkey FOREIGN KEY (lease_job_id) REFERENCES social.scrape_jobs(id) ON DELETE SET NULL;


--
-- Name: instagram_detail_run_targets instagram_detail_run_targets_run_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_detail_run_targets
    ADD CONSTRAINT instagram_detail_run_targets_run_id_fkey FOREIGN KEY (run_id) REFERENCES social.scrape_runs(id) ON DELETE CASCADE;


--
-- Name: instagram_ingestion_commands instagram_ingestion_commands_run_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_ingestion_commands
    ADD CONSTRAINT instagram_ingestion_commands_run_id_fkey FOREIGN KEY (run_id) REFERENCES social.instagram_ingestion_runs(run_id);


--
-- Name: instagram_ingestion_comment_pages instagram_ingestion_comment_p_evidence_id_run_id_stage_tar_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_ingestion_comment_pages
    ADD CONSTRAINT instagram_ingestion_comment_p_evidence_id_run_id_stage_tar_fkey FOREIGN KEY (evidence_id, run_id, stage, target_key) REFERENCES social.instagram_ingestion_evidence(evidence_id, run_id, stage, target_key);


--
-- Name: instagram_ingestion_comment_pages instagram_ingestion_comment_pages_run_id_stage_target_key_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_ingestion_comment_pages
    ADD CONSTRAINT instagram_ingestion_comment_pages_run_id_stage_target_key_fkey FOREIGN KEY (run_id, stage, target_key) REFERENCES social.instagram_ingestion_targets(run_id, stage, target_key);


--
-- Name: instagram_ingestion_decisions instagram_ingestion_decisions_execution_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_ingestion_decisions
    ADD CONSTRAINT instagram_ingestion_decisions_execution_id_fkey FOREIGN KEY (execution_id) REFERENCES social.instagram_ingestion_partitions(execution_id);


--
-- Name: instagram_ingestion_discovery_pages instagram_ingestion_discovery_pages_run_id_stage_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_ingestion_discovery_pages
    ADD CONSTRAINT instagram_ingestion_discovery_pages_run_id_stage_fkey FOREIGN KEY (run_id, stage) REFERENCES social.instagram_ingestion_manifests(run_id, stage);


--
-- Name: instagram_ingestion_dispatches instagram_ingestion_dispatches_run_id_stage_target_key_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_ingestion_dispatches
    ADD CONSTRAINT instagram_ingestion_dispatches_run_id_stage_target_key_fkey FOREIGN KEY (run_id, stage, target_key) REFERENCES social.instagram_ingestion_targets(run_id, stage, target_key);


--
-- Name: instagram_ingestion_evidence instagram_ingestion_evidence_run_id_stage_target_key_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_ingestion_evidence
    ADD CONSTRAINT instagram_ingestion_evidence_run_id_stage_target_key_fkey FOREIGN KEY (run_id, stage, target_key) REFERENCES social.instagram_ingestion_targets(run_id, stage, target_key);


--
-- Name: instagram_ingestion_manifests instagram_ingestion_manifests_run_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_ingestion_manifests
    ADD CONSTRAINT instagram_ingestion_manifests_run_id_fkey FOREIGN KEY (run_id) REFERENCES social.instagram_ingestion_runs(run_id);


--
-- Name: instagram_ingestion_outbox instagram_ingestion_outbox_run_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_ingestion_outbox
    ADD CONSTRAINT instagram_ingestion_outbox_run_id_fkey FOREIGN KEY (run_id) REFERENCES social.instagram_ingestion_runs(run_id);


--
-- Name: instagram_ingestion_partitions instagram_ingestion_partitions_run_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_ingestion_partitions
    ADD CONSTRAINT instagram_ingestion_partitions_run_id_fkey FOREIGN KEY (run_id) REFERENCES social.instagram_ingestion_runs(run_id);


--
-- Name: instagram_ingestion_receipts instagram_ingestion_receipts_evidence_id_run_id_stage_targ_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_ingestion_receipts
    ADD CONSTRAINT instagram_ingestion_receipts_evidence_id_run_id_stage_targ_fkey FOREIGN KEY (evidence_id, run_id, stage, target_key) REFERENCES social.instagram_ingestion_evidence(evidence_id, run_id, stage, target_key);


--
-- Name: instagram_ingestion_receipts instagram_ingestion_receipts_run_id_stage_target_key_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_ingestion_receipts
    ADD CONSTRAINT instagram_ingestion_receipts_run_id_stage_target_key_fkey FOREIGN KEY (run_id, stage, target_key) REFERENCES social.instagram_ingestion_targets(run_id, stage, target_key);


--
-- Name: instagram_ingestion_runs instagram_ingestion_runs_run_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_ingestion_runs
    ADD CONSTRAINT instagram_ingestion_runs_run_id_fkey FOREIGN KEY (run_id) REFERENCES social.scrape_runs(id) ON DELETE RESTRICT;


--
-- Name: instagram_ingestion_targets instagram_ingestion_targets_run_id_stage_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_ingestion_targets
    ADD CONSTRAINT instagram_ingestion_targets_run_id_stage_fkey FOREIGN KEY (run_id, stage) REFERENCES social.instagram_ingestion_manifests(run_id, stage);


--
-- Name: instagram_post_comments_audit instagram_post_comments_audit_post_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_post_comments_audit
    ADD CONSTRAINT instagram_post_comments_audit_post_id_fkey FOREIGN KEY (post_id) REFERENCES social.instagram_posts(id) ON DELETE CASCADE;


--
-- Name: instagram_post_comments_audit instagram_post_comments_audit_scrape_job_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_post_comments_audit
    ADD CONSTRAINT instagram_post_comments_audit_scrape_job_id_fkey FOREIGN KEY (scrape_job_id) REFERENCES social.scrape_jobs(id) ON DELETE SET NULL;


--
-- Name: instagram_post_comments_audit instagram_post_comments_audit_scrape_run_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_post_comments_audit
    ADD CONSTRAINT instagram_post_comments_audit_scrape_run_id_fkey FOREIGN KEY (scrape_run_id) REFERENCES social.scrape_runs(id) ON DELETE SET NULL;


--
-- Name: instagram_post_payloads instagram_post_payloads_post_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_post_payloads
    ADD CONSTRAINT instagram_post_payloads_post_id_fkey FOREIGN KEY (post_id) REFERENCES social.instagram_posts(id) ON DELETE CASCADE;


--
-- Name: instagram_posts instagram_posts_job_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_posts
    ADD CONSTRAINT instagram_posts_job_id_fkey FOREIGN KEY (job_id) REFERENCES social.scrape_jobs(id) ON DELETE SET NULL;


--
-- Name: instagram_posts instagram_posts_person_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_posts
    ADD CONSTRAINT instagram_posts_person_id_fkey FOREIGN KEY (person_id) REFERENCES core.people(id) ON DELETE SET NULL;


--
-- Name: instagram_posts instagram_posts_season_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_posts
    ADD CONSTRAINT instagram_posts_season_id_fkey FOREIGN KEY (season_id) REFERENCES core.seasons(id) ON DELETE SET NULL;


--
-- Name: instagram_posts instagram_posts_show_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.instagram_posts
    ADD CONSTRAINT instagram_posts_show_id_fkey FOREIGN KEY (show_id) REFERENCES core.shows(id) ON DELETE SET NULL;


--
-- Name: scrape_workers scrape_workers_current_job_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.scrape_workers
    ADD CONSTRAINT scrape_workers_current_job_id_fkey FOREIGN KEY (current_job_id) REFERENCES social.scrape_jobs(id) ON DELETE SET NULL;


--
-- Name: scrape_workers scrape_workers_run_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.scrape_workers
    ADD CONSTRAINT scrape_workers_run_id_fkey FOREIGN KEY (run_id) REFERENCES social.scrape_runs(id) ON DELETE SET NULL;


--
-- Name: shared_account_sources shared_account_sources_last_scrape_job_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.shared_account_sources
    ADD CONSTRAINT shared_account_sources_last_scrape_job_id_fkey FOREIGN KEY (last_scrape_job_id) REFERENCES social.scrape_jobs(id) ON DELETE SET NULL;


--
-- Name: shared_account_sources shared_account_sources_last_scrape_run_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.shared_account_sources
    ADD CONSTRAINT shared_account_sources_last_scrape_run_id_fkey FOREIGN KEY (last_scrape_run_id) REFERENCES social.scrape_runs(id) ON DELETE SET NULL;


--
-- Name: social_post_entities social_post_entities_platform_post_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.social_post_entities
    ADD CONSTRAINT social_post_entities_platform_post_id_fkey FOREIGN KEY (platform, post_id) REFERENCES social.social_posts(platform, id) ON DELETE CASCADE;


--
-- Name: social_post_legacy_refs social_post_legacy_refs_platform_post_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.social_post_legacy_refs
    ADD CONSTRAINT social_post_legacy_refs_platform_post_id_fkey FOREIGN KEY (platform, post_id) REFERENCES social.social_posts(platform, id) ON DELETE CASCADE;


--
-- Name: social_post_media_assets social_post_media_assets_platform_post_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.social_post_media_assets
    ADD CONSTRAINT social_post_media_assets_platform_post_id_fkey FOREIGN KEY (platform, post_id) REFERENCES social.social_posts(platform, id) ON DELETE CASCADE;


--
-- Name: social_post_observations social_post_observations_detail_run_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.social_post_observations
    ADD CONSTRAINT social_post_observations_detail_run_id_fkey FOREIGN KEY (detail_run_id) REFERENCES social.scrape_runs(id) ON DELETE SET NULL;


--
-- Name: social_post_observations social_post_observations_platform_post_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.social_post_observations
    ADD CONSTRAINT social_post_observations_platform_post_id_fkey FOREIGN KEY (platform, post_id) REFERENCES social.social_posts(platform, id) ON DELETE CASCADE;


--
-- Name: social_post_observations social_post_observations_scrape_run_id_fkey; Type: FK CONSTRAINT; Schema: social; Owner: -
--

ALTER TABLE ONLY social.social_post_observations
    ADD CONSTRAINT social_post_observations_scrape_run_id_fkey FOREIGN KEY (scrape_run_id) REFERENCES social.scrape_runs(id) ON DELETE SET NULL;


--
-- Name: account_auth_cooldown; Type: ROW SECURITY; Schema: social; Owner: -
--

ALTER TABLE social.account_auth_cooldown ENABLE ROW LEVEL SECURITY;

--
-- Name: account_auth_cooldown deny_api_access_account_auth_cooldown; Type: POLICY; Schema: social; Owner: -
--

CREATE POLICY deny_api_access_account_auth_cooldown ON social.account_auth_cooldown AS RESTRICTIVE USING (false) WITH CHECK (false);


--
-- Name: instagram_detail_request_lanes; Type: ROW SECURITY; Schema: social; Owner: -
--

ALTER TABLE social.instagram_detail_request_lanes ENABLE ROW LEVEL SECURITY;

--
-- Name: instagram_detail_run_targets; Type: ROW SECURITY; Schema: social; Owner: -
--

ALTER TABLE social.instagram_detail_run_targets ENABLE ROW LEVEL SECURITY;

--
-- Name: instagram_ingestion_commands; Type: ROW SECURITY; Schema: social; Owner: -
--

ALTER TABLE social.instagram_ingestion_commands ENABLE ROW LEVEL SECURITY;

--
-- Name: instagram_ingestion_comment_pages; Type: ROW SECURITY; Schema: social; Owner: -
--

ALTER TABLE social.instagram_ingestion_comment_pages ENABLE ROW LEVEL SECURITY;

--
-- Name: instagram_ingestion_decisions; Type: ROW SECURITY; Schema: social; Owner: -
--

ALTER TABLE social.instagram_ingestion_decisions ENABLE ROW LEVEL SECURITY;

--
-- Name: instagram_ingestion_discovery_pages; Type: ROW SECURITY; Schema: social; Owner: -
--

ALTER TABLE social.instagram_ingestion_discovery_pages ENABLE ROW LEVEL SECURITY;

--
-- Name: instagram_ingestion_dispatches; Type: ROW SECURITY; Schema: social; Owner: -
--

ALTER TABLE social.instagram_ingestion_dispatches ENABLE ROW LEVEL SECURITY;

--
-- Name: instagram_ingestion_evidence; Type: ROW SECURITY; Schema: social; Owner: -
--

ALTER TABLE social.instagram_ingestion_evidence ENABLE ROW LEVEL SECURITY;

--
-- Name: instagram_ingestion_manifests; Type: ROW SECURITY; Schema: social; Owner: -
--

ALTER TABLE social.instagram_ingestion_manifests ENABLE ROW LEVEL SECURITY;

--
-- Name: instagram_ingestion_outbox; Type: ROW SECURITY; Schema: social; Owner: -
--

ALTER TABLE social.instagram_ingestion_outbox ENABLE ROW LEVEL SECURITY;

--
-- Name: instagram_ingestion_partitions; Type: ROW SECURITY; Schema: social; Owner: -
--

ALTER TABLE social.instagram_ingestion_partitions ENABLE ROW LEVEL SECURITY;

--
-- Name: instagram_ingestion_receipts; Type: ROW SECURITY; Schema: social; Owner: -
--

ALTER TABLE social.instagram_ingestion_receipts ENABLE ROW LEVEL SECURITY;

--
-- Name: instagram_ingestion_runs; Type: ROW SECURITY; Schema: social; Owner: -
--

ALTER TABLE social.instagram_ingestion_runs ENABLE ROW LEVEL SECURITY;

--
-- Name: instagram_ingestion_targets; Type: ROW SECURITY; Schema: social; Owner: -
--

ALTER TABLE social.instagram_ingestion_targets ENABLE ROW LEVEL SECURITY;

--
-- Name: instagram_post_comments_audit; Type: ROW SECURITY; Schema: social; Owner: -
--

ALTER TABLE social.instagram_post_comments_audit ENABLE ROW LEVEL SECURITY;

--
-- Name: scrape_workers; Type: ROW SECURITY; Schema: social; Owner: -
--

ALTER TABLE social.scrape_workers ENABLE ROW LEVEL SECURITY;

--
-- Name: scrape_workers scrape_workers_public_read; Type: POLICY; Schema: social; Owner: -
--

CREATE POLICY scrape_workers_public_read ON social.scrape_workers FOR SELECT TO anon, authenticated USING (true);


--
-- Name: SCHEMA dbos; Type: ACL; Schema: -; Owner: -
--

GRANT USAGE ON SCHEMA dbos TO eval_runtime;


--
-- Name: FUNCTION enqueue_workflow(workflow_name text, queue_name text, positional_args json[], named_args json, class_name text, config_name text, workflow_id text, app_version text, timeout_ms bigint, deadline_epoch_ms bigint, deduplication_id text, priority integer, queue_partition_key text, authenticated_user text, authenticated_roles text, delay_until_epoch_ms bigint, application_name text); Type: ACL; Schema: dbos; Owner: -
--

GRANT ALL ON FUNCTION dbos.enqueue_workflow(workflow_name text, queue_name text, positional_args json[], named_args json, class_name text, config_name text, workflow_id text, app_version text, timeout_ms bigint, deadline_epoch_ms bigint, deduplication_id text, priority integer, queue_partition_key text, authenticated_user text, authenticated_roles text, delay_until_epoch_ms bigint, application_name text) TO eval_runtime;


--
-- Name: FUNCTION notifications_function(); Type: ACL; Schema: dbos; Owner: -
--

GRANT ALL ON FUNCTION dbos.notifications_function() TO eval_runtime;


--
-- Name: FUNCTION send_message(destination_id text, message json, topic text, message_id text); Type: ACL; Schema: dbos; Owner: -
--

GRANT ALL ON FUNCTION dbos.send_message(destination_id text, message json, topic text, message_id text) TO eval_runtime;


--
-- Name: TABLE application_versions; Type: ACL; Schema: dbos; Owner: -
--

GRANT ALL ON TABLE dbos.application_versions TO eval_runtime;


--
-- Name: TABLE dbos_migrations; Type: ACL; Schema: dbos; Owner: -
--

GRANT ALL ON TABLE dbos.dbos_migrations TO eval_runtime;


--
-- Name: TABLE event_dispatch_kv; Type: ACL; Schema: dbos; Owner: -
--

GRANT ALL ON TABLE dbos.event_dispatch_kv TO eval_runtime;


--
-- Name: TABLE notifications; Type: ACL; Schema: dbos; Owner: -
--

GRANT ALL ON TABLE dbos.notifications TO eval_runtime;


--
-- Name: TABLE operation_outputs; Type: ACL; Schema: dbos; Owner: -
--

GRANT ALL ON TABLE dbos.operation_outputs TO eval_runtime;


--
-- Name: TABLE queues; Type: ACL; Schema: dbos; Owner: -
--

GRANT ALL ON TABLE dbos.queues TO eval_runtime;


--
-- Name: TABLE streams; Type: ACL; Schema: dbos; Owner: -
--

GRANT ALL ON TABLE dbos.streams TO eval_runtime;


--
-- Name: TABLE workflow_events; Type: ACL; Schema: dbos; Owner: -
--

GRANT ALL ON TABLE dbos.workflow_events TO eval_runtime;


--
-- Name: TABLE workflow_events_history; Type: ACL; Schema: dbos; Owner: -
--

GRANT ALL ON TABLE dbos.workflow_events_history TO eval_runtime;


--
-- Name: TABLE workflow_input; Type: ACL; Schema: dbos; Owner: -
--

GRANT ALL ON TABLE dbos.workflow_input TO eval_runtime;


--
-- Name: TABLE workflow_output; Type: ACL; Schema: dbos; Owner: -
--

GRANT ALL ON TABLE dbos.workflow_output TO eval_runtime;


--
-- Name: TABLE workflow_schedules; Type: ACL; Schema: dbos; Owner: -
--

GRANT ALL ON TABLE dbos.workflow_schedules TO eval_runtime;


--
-- Name: TABLE workflow_status; Type: ACL; Schema: dbos; Owner: -
--

GRANT ALL ON TABLE dbos.workflow_status TO eval_runtime;


--
-- Name: TABLE comment_capture_health; Type: ACL; Schema: social; Owner: -
--

GRANT SELECT ON TABLE social.comment_capture_health TO anon;
GRANT SELECT ON TABLE social.comment_capture_health TO authenticated;
GRANT SELECT ON TABLE social.comment_capture_health TO service_role;


--
-- Name: TABLE instagram_detail_request_lanes; Type: ACL; Schema: social; Owner: -
--

GRANT ALL ON TABLE social.instagram_detail_request_lanes TO service_role;


--
-- Name: TABLE instagram_detail_run_targets; Type: ACL; Schema: social; Owner: -
--

GRANT ALL ON TABLE social.instagram_detail_run_targets TO service_role;


--
-- Name: TABLE instagram_ingestion_commands; Type: ACL; Schema: social; Owner: -
--

GRANT ALL ON TABLE social.instagram_ingestion_commands TO service_role;


--
-- Name: TABLE instagram_ingestion_comment_pages; Type: ACL; Schema: social; Owner: -
--

GRANT ALL ON TABLE social.instagram_ingestion_comment_pages TO service_role;


--
-- Name: TABLE instagram_ingestion_decisions; Type: ACL; Schema: social; Owner: -
--

GRANT ALL ON TABLE social.instagram_ingestion_decisions TO service_role;


--
-- Name: TABLE instagram_ingestion_discovery_pages; Type: ACL; Schema: social; Owner: -
--

GRANT ALL ON TABLE social.instagram_ingestion_discovery_pages TO service_role;


--
-- Name: TABLE instagram_ingestion_dispatches; Type: ACL; Schema: social; Owner: -
--

GRANT ALL ON TABLE social.instagram_ingestion_dispatches TO service_role;


--
-- Name: TABLE instagram_ingestion_evidence; Type: ACL; Schema: social; Owner: -
--

GRANT ALL ON TABLE social.instagram_ingestion_evidence TO service_role;


--
-- Name: TABLE instagram_ingestion_manifests; Type: ACL; Schema: social; Owner: -
--

GRANT ALL ON TABLE social.instagram_ingestion_manifests TO service_role;


--
-- Name: TABLE instagram_ingestion_outbox; Type: ACL; Schema: social; Owner: -
--

GRANT ALL ON TABLE social.instagram_ingestion_outbox TO service_role;


--
-- Name: TABLE instagram_ingestion_partitions; Type: ACL; Schema: social; Owner: -
--

GRANT ALL ON TABLE social.instagram_ingestion_partitions TO service_role;


--
-- Name: TABLE instagram_ingestion_receipts; Type: ACL; Schema: social; Owner: -
--

GRANT ALL ON TABLE social.instagram_ingestion_receipts TO service_role;


--
-- Name: TABLE instagram_ingestion_runs; Type: ACL; Schema: social; Owner: -
--

GRANT ALL ON TABLE social.instagram_ingestion_runs TO service_role;


--
-- Name: TABLE instagram_ingestion_targets; Type: ACL; Schema: social; Owner: -
--

GRANT ALL ON TABLE social.instagram_ingestion_targets TO service_role;


--
-- Name: TABLE instagram_post_comments_audit; Type: ACL; Schema: social; Owner: -
--

GRANT ALL ON TABLE social.instagram_post_comments_audit TO service_role;


--
-- Name: TABLE scrape_workers; Type: ACL; Schema: social; Owner: -
--

GRANT SELECT ON TABLE social.scrape_workers TO anon;
GRANT SELECT ON TABLE social.scrape_workers TO authenticated;
GRANT ALL ON TABLE social.scrape_workers TO service_role;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: dbos; Owner: -
--

ALTER DEFAULT PRIVILEGES FOR ROLE eval IN SCHEMA dbos GRANT ALL ON SEQUENCES TO eval_runtime;


--
-- Name: DEFAULT PRIVILEGES FOR FUNCTIONS; Type: DEFAULT ACL; Schema: dbos; Owner: -
--

ALTER DEFAULT PRIVILEGES FOR ROLE eval IN SCHEMA dbos GRANT ALL ON FUNCTIONS TO eval_runtime;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: dbos; Owner: -
--

ALTER DEFAULT PRIVILEGES FOR ROLE eval IN SCHEMA dbos GRANT ALL ON TABLES TO eval_runtime;


--
-- PostgreSQL database dump complete
--

\unrestrict EVo4Yluyi5cwg2X06NKbof6NCWNOXM33R0lXurrFMb3MnLDCPq0CSUAXghhnyos

